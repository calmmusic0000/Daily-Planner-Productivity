"use client";

import { useStore } from "@/lib/store";
import type { Priority, RepeatRule } from "@/lib/types";

// Builds the example day from the user's prompt:
// 6:00 Wake up, 6:30 Workout, 7:30 Breakfast, 8:00 Vocabulary,
// 10:00 Amazon KDP Research, 12:00 Lunch, 13:00 Design Book Cover,
// 16:00 SEO Content, 18:00 Walking, 20:00 Family Time, 21:30 Review Goals, 22:00 Scorecard
const SAMPLE_TASKS: Array<{
  title: string;
  startTime: string;
  endTime?: string;
  estimatedMin: number;
  priority: Priority;
  categoryId: string;
  tags: string[];
  repeat: RepeatRule;
}> = [
  { title: "Wake up", startTime: "06:00", estimatedMin: 15, priority: "high", categoryId: "health", tags: ["routine"], repeat: "daily" },
  { title: "Workout", startTime: "06:30", endTime: "07:15", estimatedMin: 45, priority: "high", categoryId: "exercise", tags: ["fitness"], repeat: "daily" },
  { title: "Breakfast", startTime: "07:30", endTime: "08:00", estimatedMin: 30, priority: "medium", categoryId: "health", tags: ["meal"], repeat: "daily" },
  { title: "Study Vocabulary", startTime: "08:00", endTime: "09:30", estimatedMin: 90, priority: "high", categoryId: "study", tags: ["language"], repeat: "daily" },
  { title: "Amazon KDP Research", startTime: "10:00", endTime: "11:30", estimatedMin: 90, priority: "urgent", categoryId: "kdp", tags: ["research", "books"], repeat: "none" },
  { title: "Lunch", startTime: "12:00", endTime: "12:45", estimatedMin: 45, priority: "medium", categoryId: "health", tags: ["meal"], repeat: "daily" },
  { title: "Design Book Cover", startTime: "13:00", endTime: "15:30", estimatedMin: 150, priority: "high", categoryId: "kdp", tags: ["design", "creative"], repeat: "none" },
  { title: "SEO Content", startTime: "16:00", endTime: "17:30", estimatedMin: 90, priority: "high", categoryId: "writing", tags: ["seo", "content"], repeat: "none" },
  { title: "Walking", startTime: "18:00", endTime: "18:30", estimatedMin: 30, priority: "low", categoryId: "exercise", tags: ["light"], repeat: "daily" },
  { title: "Family Time", startTime: "20:00", endTime: "21:00", estimatedMin: 60, priority: "medium", categoryId: "family", tags: ["bonding"], repeat: "daily" },
  { title: "Review Goals", startTime: "21:30", endTime: "21:50", estimatedMin: 20, priority: "high", categoryId: "personal", tags: ["reflection"], repeat: "daily" },
  { title: "Complete Scorecard", startTime: "22:00", endTime: "22:15", estimatedMin: 15, priority: "urgent", categoryId: "personal", tags: ["review"], repeat: "daily" },
];

export function useSeedDemo() {
  const addTask = useStore((s) => s.addTask);

  return () => {
    // Seed tomorrow's date so the user sees a populated "tomorrow" preview
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowKey = tomorrow.toISOString().slice(0, 10);

    SAMPLE_TASKS.forEach((t) => {
      addTask({
        ...t,
        date: tomorrowKey,
      });
    });
  };
}
