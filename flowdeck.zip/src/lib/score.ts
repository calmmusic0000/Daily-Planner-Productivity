import type { Task, DayScore, DailyReview, AppSettings } from "./types";

// Calculate productivity score for a single day
// Score = completed*60 + priority*20 + habits*10 + timeAccuracy*10  (weights from settings)
export function calculateDayScore(
  tasks: Task[],
  date: string,
  review?: DailyReview,
  settings?: AppSettings,
): DayScore {
  const dayTasks = tasks.filter((t) => t.date === date);
  const total = dayTasks.length;
  const completed = dayTasks.filter((t) => t.status === "completed").length;
  const partial = dayTasks.filter((t) => t.status === "partial").length;
  const missed = dayTasks.filter((t) => t.status === "missed" || t.status === "pending").length;

  // Priority completion (urgent + high only)
  const priorityTasks = dayTasks.filter((t) => t.priority === "urgent" || t.priority === "high");
  const priorityTotal = priorityTasks.length;
  const priorityCompleted = priorityTasks.filter((t) => t.status === "completed").length;

  // Habits from review
  let habitsTotal = 0;
  let habitsCompleted = 0;
  if (review) {
    habitsTotal = 4; // exercise, reading, sleep>=7h, water>=8
    habitsCompleted += review.exerciseDone ? 1 : 0;
    habitsCompleted += review.readingDone ? 1 : 0;
    habitsCompleted += review.sleepHours >= 7 ? 1 : 0;
    habitsCompleted += review.waterIntake >= 8 ? 1 : 0;
  }

  // Time accuracy: % of tasks where actual <= estimated *1.25 (or no estimate, full credit if completed)
  let timeAccuracy = 100;
  const timeTracked = dayTasks.filter((t) => t.estimatedMin && t.estimatedMin > 0 && (t.status === "completed" || t.status === "partial"));
  if (timeTracked.length > 0) {
    const accSum = timeTracked.reduce((acc, t) => {
      const est = t.estimatedMin || 0;
      const act = t.actualMin ?? (t.status === "completed" ? est : est * 1.5);
      const ratio = act <= est ? 1 : est / Math.max(act, 1);
      return acc + ratio * 100;
    }, 0);
    timeAccuracy = Math.round(accSum / timeTracked.length);
  }

  // Weights
  const wC = settings?.weightCompleted ?? 60;
  const wP = settings?.weightPriority ?? 20;
  const wH = settings?.weightHabits ?? 10;
  const wT = settings?.weightTimeAccuracy ?? 10;

  const completedPct = total > 0 ? ((completed + partial * 0.5) / total) * 100 : 0;
  const priorityPct = priorityTotal > 0 ? (priorityCompleted / priorityTotal) * 100 : completedPct;
  const habitsPct = habitsTotal > 0 ? (habitsCompleted / habitsTotal) * 100 : completedPct;

  const finalScore = Math.round(
    (completedPct * wC + priorityPct * wP + habitsPct * wH + timeAccuracy * wT) / 100,
  );

  return {
    date,
    totalTasks: total,
    completedTasks: completed,
    partialTasks: partial,
    missedTasks: missed,
    priorityCompleted,
    priorityTotal,
    habitsCompleted,
    habitsTotal,
    timeAccuracy,
    finalScore: Math.min(100, Math.max(0, finalScore)),
    breakdown: {
      completed: Math.round((completedPct * wC) / 100),
      priority: Math.round((priorityPct * wP) / 100),
      habits: Math.round((habitsPct * wH) / 100),
      time: Math.round((timeAccuracy * wT) / 100),
    },
  };
}

export function scoreBand(score: number): {
  label: string;
  color: string;
  bg: string;
} {
  if (score >= 95) return { label: "Excellent", color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500" };
  if (score >= 85) return { label: "Great", color: "text-green-600 dark:text-green-400", bg: "bg-green-500" };
  if (score >= 70) return { label: "Good", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-500" };
  if (score >= 50) return { label: "Needs Work", color: "text-orange-600 dark:text-orange-400", bg: "bg-orange-500" };
  return { label: "Poor", color: "text-red-600 dark:text-red-400", bg: "bg-red-500" };
}

// XP rewards
export function xpForTask(priority: string): number {
  switch (priority) {
    case "urgent": return 30;
    case "high": return 20;
    case "medium": return 12;
    default: return 6;
  }
}

export function xpForDayScore(score: number): number {
  // 0-100 score -> 0-200 bonus XP
  return Math.round(score * 2);
}

// Level curve: level N requires 100 * N * (N+1)/2 cumulative XP
export function levelForXp(xp: number): { level: number; intoLevel: number; neededForNext: number; pct: number } {
  let level = 1;
  let remaining = xp;
  while (remaining >= 100 * level) {
    remaining -= 100 * level;
    level += 1;
  }
  const neededForNext = 100 * level;
  return {
    level,
    intoLevel: remaining,
    neededForNext,
    pct: Math.round((remaining / neededForNext) * 100),
  };
}

export function rankTitle(level: number): string {
  if (level >= 30) return "Productivity Legend";
  if (level >= 20) return "Productivity Master";
  if (level >= 15) return "Productivity Pro";
  if (level >= 10) return "Habit Builder";
  if (level >= 5) return "Consistent Achiever";
  if (level >= 3) return "Getting Started";
  return "Novice Planner";
}
