"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  Task,
  DailyReview,
  AppSettings,
  GamificationState,
  Achievement,
  Category,
  TaskStatus,
} from "./types";
import {
  DEFAULT_CATEGORIES,
  DEFAULT_SETTINGS,
} from "./types";
import { xpForTask } from "./score";

interface StoreState {
  // data
  tasks: Task[];
  reviews: Record<string, DailyReview>; // keyed by date YYYY-MM-DD
  categories: Category[];
  settings: AppSettings;
  game: GamificationState;
  // task actions
  addTask: (task: Omit<Task, "id" | "createdAt" | "updatedAt" | "status" | "order">) => string;
  updateTask: (id: string, patch: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  duplicateTask: (id: string) => void;
  setTaskStatus: (id: string, status: TaskStatus) => void;
  reorderTasks: (date: string, orderedIds: string[]) => void;
  // reviews
  saveReview: (review: DailyReview) => void;
  // categories
  addCategory: (cat: Omit<Category, "id">) => void;
  deleteCategory: (id: string) => void;
  // settings
  updateSettings: (patch: Partial<AppSettings>) => void;
  // gamification
  awardXp: (xp: number) => void;
  unlockAchievement: (a: Omit<Achievement, "unlockedAt">) => void;
  // bulk
  importData: (data: Partial<StoreState>) => void;
  clearAll: () => void;
  // internal
  _recomputeStreak: () => void;
}

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

const DEFAULT_ACHIEVEMENTS: Achievement[] = [];

const initialGame: GamificationState = {
  xp: 0,
  level: 1,
  streak: 0,
  bestStreak: 0,
  achievements: DEFAULT_ACHIEVEMENTS,
};

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      tasks: [],
      reviews: {},
      categories: DEFAULT_CATEGORIES,
      settings: DEFAULT_SETTINGS,
      game: initialGame,

      addTask: (task) => {
        const id = uid();
        const now = Date.now();
        const sameDay = get().tasks.filter((t) => t.date === task.date);
        const order = sameDay.length;
        const newTask: Task = {
          ...task,
          id,
          status: "pending",
          order,
          createdAt: now,
          updatedAt: now,
        };
        set((s) => ({ tasks: [...s.tasks, newTask] }));
        return id;
      },

      updateTask: (id, patch) =>
        set((s) => ({
          tasks: s.tasks.map((t) =>
            t.id === id ? { ...t, ...patch, updatedAt: Date.now() } : t,
          ),
        })),

      deleteTask: (id) =>
        set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),

      duplicateTask: (id) => {
        const t = get().tasks.find((x) => x.id === id);
        if (!t) return;
        const newId = uid();
        const now = Date.now();
        const copy: Task = {
          ...t,
          id: newId,
          title: `${t.title} (copy)`,
          status: "pending",
          completedAt: undefined,
          actualMin: undefined,
          createdAt: now,
          updatedAt: now,
        };
        set((s) => ({ tasks: [...s.tasks, copy] }));
      },

      setTaskStatus: (id, status) => {
        const task = get().tasks.find((t) => t.id === id);
        if (!task) return;
        const wasCompleted = task.status === "completed";
        const isCompleted = status === "completed";
        const updates: Partial<Task> = {
          status,
          completedAt: status === "completed" ? Date.now() : undefined,
          updatedAt: Date.now(),
        };
        set((s) => ({
          tasks: s.tasks.map((t) => (t.id === id ? { ...t, ...updates } : t)),
        }));
        // Award XP when transitioning to completed
        if (!wasCompleted && isCompleted) {
          get().awardXp(xpForTask(task.priority));
          // Re-evaluate streak
          get()._recomputeStreak();
        }
      },

      reorderTasks: (_date, orderedIds) =>
        set((s) => ({
          tasks: s.tasks.map((t) => {
            const idx = orderedIds.indexOf(t.id);
            if (idx === -1) return t;
            return { ...t, order: idx };
          }),
        })),

      saveReview: (review) => {
        set((s) => {
          // If first review of the day OR replacing, just store
          return { reviews: { ...s.reviews, [review.date]: review } };
        });
        // Award XP based on submitting review + today's score
        // Note: score computation done in component to avoid circular dep
      },

      addCategory: (cat) =>
        set((s) => ({
          categories: [...s.categories, { ...cat, id: uid() }],
        })),

      deleteCategory: (id) =>
        set((s) => ({
          categories: s.categories.filter((c) => c.id !== id),
        })),

      updateSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),

      awardXp: (xp) =>
        set((s) => {
          const newXp = Math.max(0, s.game.xp + xp);
          // Level recomputed in selector, but store best streak etc
          return {
            game: {
              ...s.game,
              xp: newXp,
              lastXpEarnedAt: Date.now(),
            },
          };
        }),

      unlockAchievement: (a) =>
        set((s) => {
          if (s.game.achievements.some((x) => x.id === a.id)) return s;
          return {
            game: {
              ...s.game,
              achievements: [...s.game.achievements, { ...a, unlockedAt: Date.now() }],
            },
          };
        }),

      importData: (data) =>
        set((s) => ({
          tasks: data.tasks ?? s.tasks,
          reviews: data.reviews ?? s.reviews,
          categories: data.categories ?? s.categories,
          settings: data.settings ?? s.settings,
          game: data.game ?? s.game,
        })),

      clearAll: () =>
        set({
          tasks: [],
          reviews: {},
          categories: DEFAULT_CATEGORIES,
          settings: DEFAULT_SETTINGS,
          game: initialGame,
        }),

      // internal helper — kept on store for typing simplicity
      _recomputeStreak: () => {
        const { tasks, reviews } = get();
        // streak = number of consecutive days ending today or yesterday with score >= 70 OR a submitted review
        const today = new Date();
        let streak = 0;
        for (let i = 0; i < 365; i++) {
          const d = new Date(today);
          d.setDate(d.getDate() - i);
          const key = d.toISOString().slice(0, 10);
          const review = reviews[key];
          const dayTasks = tasks.filter((t) => t.date === key);
          // A day counts toward streak if: review submitted OR all tasks completed/partial/missed (i.e. day has finished)
          const hasActivity = !!review || dayTasks.length > 0;
          const completed = dayTasks.filter((t) => t.status === "completed").length;
          const enoughDone = dayTasks.length === 0 ? !!review : completed >= dayTasks.length * 0.5;
          if (i === 0 && !hasActivity) {
            // today not done yet, don't break streak
            continue;
          }
          if (hasActivity && enoughDone) {
            streak += 1;
          } else {
            break;
          }
        }
        set((s) => ({
          game: {
            ...s.game,
            streak,
            bestStreak: Math.max(s.game.bestStreak, streak),
          },
        }));
      },
    }),
    {
      name: "prod-dashboard-v1",
      version: 1,
    },
  ),
);
