// Core domain types for the productivity system

export type Priority = "low" | "medium" | "high" | "urgent";
export type TaskStatus = "pending" | "completed" | "partial" | "missed";
export type RepeatRule = "none" | "daily" | "weekly" | "monthly";

export interface Category {
  id: string;
  name: string;
  color: string; // tailwind color name e.g. "amber"
  icon?: string;
}

export interface Task {
  id: string;
  title: string;
  notes?: string;
  date: string; // YYYY-MM-DD (the day this task is scheduled)
  startTime?: string; // HH:mm 24h
  endTime?: string; // HH:mm 24h
  estimatedMin?: number;
  actualMin?: number;
  priority: Priority;
  categoryId: string;
  tags: string[];
  repeat: RepeatRule;
  status: TaskStatus;
  color?: string;
  createdAt: number;
  updatedAt: number;
  completedAt?: number;
  order: number;
}

export interface DailyReview {
  date: string; // YYYY-MM-DD
  wentWell: string;
  didNotGoWell: string;
  biggestDistraction: string;
  mood: number; // 1-10
  energy: number; // 1-10
  sleepHours: number;
  waterIntake: number; // glasses
  exerciseDone: boolean;
  readingDone: boolean;
  achievement: string;
  tomorrowFocus: string;
  submittedAt: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt: number;
}

export interface AppSettings {
  theme: "light" | "dark" | "system";
  accent: string; // tailwind accent color name
  wakeTime: string; // HH:mm
  sleepTime: string; // HH:mm
  morningReminder: boolean;
  morningReminderTime: string;
  eveningReminder: boolean;
  eveningReminderTime: string;
  taskReminderLeadMin: number; // minutes before task
  weekendMode: boolean;
  // scoring weights (must sum to 100)
  weightCompleted: number;
  weightPriority: number;
  weightHabits: number;
  weightTimeAccuracy: number;
}

export interface DayScore {
  date: string;
  totalTasks: number;
  completedTasks: number;
  partialTasks: number;
  missedTasks: number;
  priorityCompleted: number;
  priorityTotal: number;
  habitsCompleted: number;
  habitsTotal: number;
  timeAccuracy: number; // 0-100
  finalScore: number; // 0-100
  breakdown: {
    completed: number;
    priority: number;
    habits: number;
    time: number;
  };
}

export interface GamificationState {
  xp: number;
  level: number;
  streak: number;
  bestStreak: number;
  achievements: Achievement[];
  lastXpEarnedAt?: number;
}

// Default categories matching the user's spec
export const DEFAULT_CATEGORIES: Category[] = [
  { id: "study", name: "Study", color: "blue" },
  { id: "business", name: "Business", color: "purple" },
  { id: "kdp", name: "Amazon KDP", color: "orange" },
  { id: "exercise", name: "Exercise", color: "red" },
  { id: "reading", name: "Reading", color: "emerald" },
  { id: "writing", name: "Writing", color: "pink" },
  { id: "health", name: "Health", color: "teal" },
  { id: "family", name: "Family", color: "rose" },
  { id: "finance", name: "Finance", color: "green" },
  { id: "personal", name: "Personal", color: "amber" },
  { id: "learning", name: "Learning", color: "cyan" },
  { id: "work", name: "Work", color: "slate" },
];

export const DEFAULT_SETTINGS: AppSettings = {
  theme: "system",
  accent: "emerald",
  wakeTime: "06:00",
  sleepTime: "22:30",
  morningReminder: true,
  morningReminderTime: "07:00",
  eveningReminder: true,
  eveningReminderTime: "21:30",
  taskReminderLeadMin: 10,
  weekendMode: false,
  weightCompleted: 60,
  weightPriority: 20,
  weightHabits: 10,
  weightTimeAccuracy: 10,
};

// Color name → tailwind utility classes (must be inline since Tailwind can't see dynamic strings)
export const CATEGORY_COLOR_MAP: Record<
  string,
  { dot: string; bg: string; text: string; border: string; soft: string }
> = {
  amber: { dot: "bg-amber-500", bg: "bg-amber-500", text: "text-amber-600 dark:text-amber-400", border: "border-amber-500/40", soft: "bg-amber-500/10" },
  blue: { dot: "bg-blue-500", bg: "bg-blue-500", text: "text-blue-600 dark:text-blue-400", border: "border-blue-500/40", soft: "bg-blue-500/10" },
  purple: { dot: "bg-purple-500", bg: "bg-purple-500", text: "text-purple-600 dark:text-purple-400", border: "border-purple-500/40", soft: "bg-purple-500/10" },
  orange: { dot: "bg-orange-500", bg: "bg-orange-500", text: "text-orange-600 dark:text-orange-400", border: "border-orange-500/40", soft: "bg-orange-500/10" },
  red: { dot: "bg-red-500", bg: "bg-red-500", text: "text-red-600 dark:text-red-400", border: "border-red-500/40", soft: "bg-red-500/10" },
  emerald: { dot: "bg-emerald-500", bg: "bg-emerald-500", text: "text-emerald-600 dark:text-emerald-400", border: "border-emerald-500/40", soft: "bg-emerald-500/10" },
  pink: { dot: "bg-pink-500", bg: "bg-pink-500", text: "text-pink-600 dark:text-pink-400", border: "border-pink-500/40", soft: "bg-pink-500/10" },
  teal: { dot: "bg-teal-500", bg: "bg-teal-500", text: "text-teal-600 dark:text-teal-400", border: "border-teal-500/40", soft: "bg-teal-500/10" },
  rose: { dot: "bg-rose-500", bg: "bg-rose-500", text: "text-rose-600 dark:text-rose-400", border: "border-rose-500/40", soft: "bg-rose-500/10" },
  green: { dot: "bg-green-500", bg: "bg-green-500", text: "text-green-600 dark:text-green-400", border: "border-green-500/40", soft: "bg-green-500/10" },
  cyan: { dot: "bg-cyan-500", bg: "bg-cyan-500", text: "text-cyan-600 dark:text-cyan-400", border: "border-cyan-500/40", soft: "bg-cyan-500/10" },
  slate: { dot: "bg-slate-500", bg: "bg-slate-500", text: "text-slate-600 dark:text-slate-400", border: "border-slate-500/40", soft: "bg-slate-500/10" },
};

export function colorOf(name: string) {
  return CATEGORY_COLOR_MAP[name] ?? CATEGORY_COLOR_MAP.slate;
}

export const PRIORITY_META: Record<
  Priority,
  { label: string; color: string; weight: number; ring: string }
> = {
  urgent: { label: "Urgent", color: "text-red-600 dark:text-red-400", weight: 4, ring: "ring-red-500/50" },
  high: { label: "High", color: "text-orange-600 dark:text-orange-400", weight: 3, ring: "ring-orange-500/50" },
  medium: { label: "Medium", color: "text-amber-600 dark:text-amber-400", weight: 2, ring: "ring-amber-500/50" },
  low: { label: "Low", color: "text-slate-600 dark:text-slate-400", weight: 1, ring: "ring-slate-500/50" },
};
