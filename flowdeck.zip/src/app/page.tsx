"use client";

import * as React from "react";
import {
  LayoutDashboard,
  ListTodo,
  Calendar,
  BarChart3,
  Trophy,
  Settings,
  Moon,
  Sun,
  Sparkles,
  Menu,
  X,
} from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useStore } from "@/lib/store";
import { Dashboard } from "@/components/dashboard/dashboard";
import { TasksView } from "@/components/tasks/tasks-view";
import { CalendarView } from "@/components/calendar-view/calendar-view";
import { ReportsView } from "@/components/reports/reports-view";
import { GamificationView } from "@/components/gamification/gamification-view";
import { SettingsView } from "@/components/settings/settings-view";
import { ReviewModal } from "@/components/review/review-modal";
import { ReminderEngine, EnableNotificationsButton } from "@/components/common/reminder-engine";

type Tab = "dashboard" | "tasks" | "calendar" | "reports" | "gamification" | "settings";

const NAV_ITEMS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-4 w-4" /> },
  { id: "tasks", label: "Tasks", icon: <ListTodo className="h-4 w-4" /> },
  { id: "calendar", label: "Calendar", icon: <Calendar className="h-4 w-4" /> },
  { id: "reports", label: "Reports", icon: <BarChart3 className="h-4 w-4" /> },
  { id: "gamification", label: "Achievements", icon: <Trophy className="h-4 w-4" /> },
  { id: "settings", label: "Settings", icon: <Settings className="h-4 w-4" /> },
];

export default function Home() {
  const [tab, setTab] = React.useState<Tab>("dashboard");
  const [reviewOpen, setReviewOpen] = React.useState(false);
  const [reviewDate, setReviewDate] = React.useState<string | undefined>(undefined);
  const [mobileNavOpen, setMobileNavOpen] = React.useState(false);
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  const tasks = useStore((s) => s.tasks);
  const todayKey = new Date().toISOString().slice(0, 10);
  const todayTaskCount = tasks.filter((t) => t.date === todayKey).length;

  const openReview = (date?: string) => {
    setReviewDate(date);
    setReviewOpen(true);
  };

  const navigate = (t: string) => {
    setTab(t as Tab);
    setMobileNavOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <ReminderEngine />

      {/* Top bar (mobile + desktop) */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex items-center justify-between px-3 sm:px-6 h-14">
          <div className="flex items-center gap-3">
            {/* Mobile nav trigger */}
            <Sheet open={mobileNavOpen} onOpenChange={setMobileNavOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0">
                <SidebarContent
                  tab={tab}
                  navigate={navigate}
                  todayTaskCount={todayTaskCount}
                />
              </SheetContent>
            </Sheet>

            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
              <div>
                <h1 className="text-base font-semibold leading-none">FlowDeck</h1>
                <p className="text-[10px] text-muted-foreground hidden sm:block">Plan · Track · Score · Improve</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <EnableNotificationsButton />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              title="Toggle theme"
              className="h-9 w-9"
            >
              {mounted && theme === "dark" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </Button>
            <Button
              onClick={() => openReview(todayKey)}
              size="sm"
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              <Sparkles className="h-3.5 w-3.5 mr-1" />
              <span className="hidden sm:inline">Nightly Review</span>
              <span className="sm:hidden">Review</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Desktop sidebar */}
        <aside className="hidden lg:flex w-60 flex-col border-r bg-card/30">
          <SidebarContent
            tab={tab}
            navigate={navigate}
            todayTaskCount={todayTaskCount}
          />
        </aside>

        {/* Main content */}
        <main className="flex-1 min-w-0 p-3 sm:p-6">
          <div className="mx-auto max-w-6xl">
            {tab === "dashboard" && (
              <Dashboard onNavigate={navigate} onOpenReview={() => openReview(todayKey)} />
            )}
            {tab === "tasks" && <TasksView onOpenReview={openReview} />}
            {tab === "calendar" && <CalendarView />}
            {tab === "reports" && <ReportsView />}
            {tab === "gamification" && <GamificationView />}
            {tab === "settings" && <SettingsView />}
          </div>
        </main>
      </div>

      <footer className="border-t mt-auto py-3 px-6 text-center text-xs text-muted-foreground">
        FlowDeck · Your data stays in your browser · Plan tomorrow tonight
      </footer>

      <ReviewModal open={reviewOpen} onOpenChange={setReviewOpen} date={reviewDate} />
    </div>
  );
}

function SidebarContent({
  tab,
  navigate,
  todayTaskCount,
}: {
  tab: Tab;
  navigate: (t: string) => void;
  todayTaskCount: number;
}) {
  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-semibold leading-none">FlowDeck</h1>
            <p className="text-[10px] text-muted-foreground mt-0.5">Productivity OS</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-1">
        {NAV_ITEMS.map((item) => {
          const active = tab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-md text-sm transition ${
                active
                  ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-medium"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <span className="flex items-center gap-2">
                {item.icon}
                {item.label}
              </span>
              {item.id === "tasks" && todayTaskCount > 0 && (
                <Badge variant="secondary" className="text-[10px]">
                  {todayTaskCount}
                </Badge>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t text-[10px] text-muted-foreground">
        <p className="font-medium text-foreground mb-0.5">Daily Flow</p>
        <p>1. Plan tomorrow tonight</p>
        <p>2. Track during the day</p>
        <p>3. Review & score at night</p>
        <p>4. Get AI coaching</p>
      </div>
    </div>
  );
}
