import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

interface TaskDTO {
  id: string;
  title: string;
  date: string;
  startTime?: string;
  endTime?: string;
  priority: string;
  categoryId: string;
  status: string;
  estimatedMin?: number;
  tags: string[];
}

interface ReviewDTO {
  date: string;
  wentWell: string;
  didNotGoWell: string;
  biggestDistraction: string;
  mood: number;
  energy: number;
  sleepHours: number;
  waterIntake: number;
  exerciseDone: boolean;
  readingDone: boolean;
  achievement: string;
  tomorrowFocus: string;
}

interface ScoreDTO {
  finalScore: number;
  totalTasks: number;
  completedTasks: number;
  partialTasks: number;
  missedTasks: number;
  priorityCompleted: number;
  priorityTotal: number;
  habitsCompleted: number;
  habitsTotal: number;
  timeAccuracy: number;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { date, tasks, review, score } = body as {
      date: string;
      tasks: TaskDTO[];
      review: ReviewDTO;
      score: ScoreDTO;
    };

    const completedTitles = tasks
      .filter((t) => t.status === "completed")
      .map((t) => `- ${t.title}${t.startTime ? ` (${t.startTime})` : ""} [${t.priority}]`)
      .join("\n");
    const missedTitles = tasks
      .filter((t) => t.status === "missed")
      .map((t) => `- ${t.title}${t.startTime ? ` (${t.startTime})` : ""} [${t.priority}]`)
      .join("\n");
    const partialTitles = tasks
      .filter((t) => t.status === "partial")
      .map((t) => `- ${t.title}${t.startTime ? ` (${t.startTime})` : ""} [${t.priority}]`)
      .join("\n");

    const summary = `
Date: ${date}
Daily Score: ${score.finalScore}/100
  - Completed: ${score.completedTasks}/${score.totalTasks} tasks
  - Partial: ${score.partialTasks}
  - Missed: ${score.missedTasks}
  - High-priority completion: ${score.priorityCompleted}/${score.priorityTotal}
  - Habits: ${score.habitsCompleted}/${score.habitsTotal}
  - Time accuracy: ${score.timeAccuracy}%

COMPLETED:
${completedTitles || "(none)"}

PARTIAL:
${partialTitles || "(none)"}

MISSED:
${missedTitles || "(none)"}

REFLECTION:
- Went well: ${review.wentWell || "(not answered)"}
- Didn't go well: ${review.didNotGoWell || "(not answered)"}
- Biggest distraction: ${review.biggestDistraction || "(not answered)"}
- Mood: ${review.mood}/10
- Energy: ${review.energy}/10
- Sleep: ${review.sleepHours}h
- Water: ${review.waterIntake} glasses
- Exercise: ${review.exerciseDone ? "yes" : "no"}
- Reading: ${review.readingDone ? "yes" : "no"}
- Achievement: ${review.achievement || "(not answered)"}
- Tomorrow's focus: ${review.tomorrowFocus || "(not answered)"}
`.trim();

    const systemPrompt = `You are a kind, practical productivity coach helping a user reflect on their day.
Analyze their performance data and provide a concise, actionable insight.

Format your response as EXACTLY 3 short paragraphs separated by blank lines:
1. One-sentence acknowledgment of what they accomplished today (specific, not generic).
2. The single most impactful improvement for tomorrow — be specific (e.g. "Schedule creative work before 11am when energy is high", "Move exercise earlier to avoid skipping it").
3. A short motivational close tied to their data.

Keep total response under 120 words. No emojis, no lists, no headers — just plain prose.`;

    const userPrompt = `Here is my day's data:\n\n${summary}\n\nPlease give me coaching feedback.`;

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.7,
      max_tokens: 250,
    });

    const insight =
      completion.choices?.[0]?.message?.content?.trim() ||
      "Unable to generate insight. Please try again.";

    return NextResponse.json({ insight, summary });
  } catch (err) {
    console.error("[AI Analysis Error]", err);
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json(
      {
        error: message,
        insight: null,
      },
      { status: 500 },
    );
  }
}
