"use client";

import * as React from "react";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/store";
import { calculateDayScore, scoreBand } from "@/lib/score";
import { TaskForm } from "@/components/tasks/task-form";
import type { Task } from "@/lib/types";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function CalendarView() {
  const tasks = useStore((s) => s.tasks);
  const reviews = useStore((s) => s.reviews);
  const settings = useStore((s) => s.settings);

  const [cursor, setCursor] = React.useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const [selectedDate, setSelectedDate] = React.useState(
    new Date().toISOString().slice(0, 10),
  );
  const [formOpen, setFormOpen] = React.useState(false);

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const firstDay = new Date(year, month, 1);
  const startWeekday = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const today = new Date().toISOString().slice(0, 10);

  const cells: (string | null)[] = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(year, month, d);
    cells.push(date.toISOString().slice(0, 10));
  }
  while (cells.length % 7 !== 0) cells.push(null);

  const cellScore = (date: string) => {
    if (!reviews[date] && tasks.filter((t) => t.date === date).length === 0) return null;
    return calculateDayScore(tasks, date, reviews[date], settings).finalScore;
  };

  const selectedTasks = tasks.filter((t) => t.date === selectedDate);

  const prevMonth = () => setCursor(new Date(year, month - 1, 1));
  const nextMonth = () => setCursor(new Date(year, month + 1, 1));

  return (
    <div className="space-y-4">
      <Card className="p-4 sm:p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold">
              {cursor.toLocaleDateString(undefined, { month: "long", year: "numeric" })}
            </h2>
            <p className="text-xs text-muted-foreground">Tap a day to see tasks. Color = score.</p>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" onClick={prevMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                const d = new Date();
                setCursor(new Date(d.getFullYear(), d.getMonth(), 1));
                setSelectedDate(today);
              }}
            >
              Today
            </Button>
            <Button variant="outline" size="icon" onClick={nextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Weekday header */}
        <div className="grid grid-cols-7 gap-1 mb-1">
          {WEEKDAYS.map((w) => (
            <div key={w} className="text-center text-[10px] sm:text-xs font-medium text-muted-foreground py-1">
              {w.slice(0, 2)}
            </div>
          ))}
        </div>

        {/* Calendar grid */}
        <div className="grid grid-cols-7 gap-1">
          {cells.map((date, i) => {
            if (!date) return <div key={i} className="aspect-square" />;
            const score = cellScore(date);
            const isSelected = date === selectedDate;
            const isToday = date === today;
            const dayTasks = tasks.filter((t) => t.date === date);
            const dayNum = parseInt(date.slice(8, 10), 10);
            const band = score !== null ? scoreBand(score) : null;
            return (
              <button
                key={date}
                onClick={() => setSelectedDate(date)}
                className={`aspect-square rounded-md p-1 sm:p-1.5 flex flex-col items-stretch text-left border transition-all relative ${
                  isSelected
                    ? "border-emerald-500 ring-1 ring-emerald-500/50"
                    : "border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                } ${isToday ? "bg-emerald-500/10" : ""}`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`text-[10px] sm:text-xs font-medium ${
                      isToday ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"
                    }`}
                  >
                    {dayNum}
                  </span>
                  {dayTasks.length > 0 && (
                    <span className="text-[9px] text-muted-foreground hidden sm:inline">
                      {dayTasks.length}
                    </span>
                  )}
                </div>
                {band && (
                  <div className="mt-auto flex flex-col gap-0.5">
                    <div className={`h-1 rounded-full ${band.bg}`} />
                    <span className={`text-[9px] sm:text-[10px] font-semibold ${band.color} hidden sm:inline`}>
                      {score}
                    </span>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-3 mt-4 pt-3 border-t text-[10px] text-muted-foreground">
          <span>Score legend:</span>
          <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500" /> 95+</span>
          <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500" /> 85+</span>
          <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500" /> 70+</span>
          <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-orange-500" /> 50+</span>
          <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" /> &lt;50</span>
        </div>
      </Card>

      {/* Selected day's tasks */}
      <Card className="p-4 sm:p-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold">
              {new Date(selectedDate + "T00:00:00").toLocaleDateString(undefined, {
                weekday: "long",
                month: "long",
                day: "numeric",
              })}
            </h3>
            <p className="text-xs text-muted-foreground">{selectedTasks.length} task(s)</p>
          </div>
          <Button size="sm" onClick={() => setFormOpen(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white">
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add
          </Button>
        </div>
        {selectedTasks.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-6">No tasks on this day.</p>
        ) : (
          <div className="space-y-2">
            {selectedTasks
              .sort((a, b) => (a.startTime ?? "z").localeCompare(b.startTime ?? "z"))
              .map((t) => (
                <TaskPill key={t.id} task={t} />
              ))}
          </div>
        )}
      </Card>

      <TaskForm open={formOpen} onOpenChange={setFormOpen} defaultDate={selectedDate} />
    </div>
  );
}

function TaskPill({ task }: { task: Task }) {
  const categories = useStore((s) => s.categories);
  const category = categories.find((c) => c.id === task.categoryId);
  const statusColor =
    task.status === "completed"
      ? "bg-emerald-500/15 border-emerald-500/30"
      : task.status === "partial"
      ? "bg-amber-500/15 border-amber-500/30"
      : task.status === "missed"
      ? "bg-red-500/15 border-red-500/30"
      : "bg-slate-500/5 border-slate-500/20";
  return (
    <div className={`flex items-center gap-3 p-2.5 rounded-md border ${statusColor}`}>
      <div className="text-xs font-mono text-muted-foreground w-12">
        {task.startTime ?? "—"}
      </div>
      <div className="flex-1 min-w-0">
        <div className={`text-sm font-medium truncate ${task.status === "completed" ? "line-through opacity-60" : ""}`}>
          {task.title}
        </div>
        {category && (
          <div className="text-[10px] text-muted-foreground">{category.name}</div>
        )}
      </div>
      <Badge variant="outline" className="text-[10px] capitalize">
        {task.status}
      </Badge>
    </div>
  );
}
