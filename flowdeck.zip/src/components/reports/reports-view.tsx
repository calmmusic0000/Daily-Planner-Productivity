"use client";

import * as React from "react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
} from "recharts";
import { Card } from "@/components/ui/card";
import { TrendingUp, Award, Clock, Target, Calendar as CalIcon, Flame } from "lucide-react";
import { useStore } from "@/lib/store";
import { calculateDayScore, scoreBand } from "@/lib/score";
import { colorOf } from "@/lib/types";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";

const CHART_COLORS = ["#10b981", "#f59e0b", "#3b82f6", "#ec4899", "#8b5cf6", "#ef4444", "#14b8a6", "#84cc16", "#06b6d4", "#f97316", "#6366f1", "#64748b"];

export function ReportsView() {
  const tasks = useStore((s) => s.tasks);
  const reviews = useStore((s) => s.reviews);
  const settings = useStore((s) => s.settings);
  const categories = useStore((s) => s.categories);
  const game = useStore((s) => s.game);

  // Generate last 30 days of scores
  const last30 = React.useMemo(() => {
    const arr: { date: string; label: string; score: number; tasks: number; completed: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      const score = calculateDayScore(tasks, key, reviews[key], settings).finalScore;
      const dayTasks = tasks.filter((t) => t.date === key);
      const completed = dayTasks.filter((t) => t.status === "completed").length;
      arr.push({
        date: key,
        label: d.toLocaleDateString(undefined, { month: "short", day: "numeric" }),
        score,
        tasks: dayTasks.length,
        completed,
      });
    }
    return arr;
  }, [tasks, reviews, settings]);

  // Weekly aggregates
  const weeklyData = React.useMemo(() => {
    const weeks: { label: string; avg: number; completion: number; tasks: number }[] = [];
    for (let w = 5; w >= 0; w--) {
      const end = new Date();
      end.setDate(end.getDate() - w * 7);
      const start = new Date(end);
      start.setDate(start.getDate() - 6);
      const slice = last30.filter((d) => {
        const dd = new Date(d.date + "T00:00:00");
        return dd >= start && dd <= end;
      });
      const withScores = slice.filter((s) => s.tasks > 0);
      const avg = withScores.length > 0
        ? Math.round(withScores.reduce((a, b) => a + b.score, 0) / withScores.length)
        : 0;
      const totalTasks = slice.reduce((a, b) => a + b.tasks, 0);
      const totalDone = slice.reduce((a, b) => a + b.completed, 0);
      const completion = totalTasks > 0 ? Math.round((totalDone / totalTasks) * 100) : 0;
      weeks.push({
        label: `W${6 - w}`,
        avg,
        completion,
        tasks: totalTasks,
      });
    }
    return weeks;
  }, [last30]);

  // Category breakdown (time spent per category, last 30 days)
  const categoryData = React.useMemo(() => {
    const map = new Map<string, number>();
    tasks.forEach((t) => {
      const minutes = t.actualMin ?? t.estimatedMin ?? 30;
      map.set(t.categoryId, (map.get(t.categoryId) ?? 0) + minutes);
    });
    return Array.from(map.entries())
      .map(([id, minutes]) => {
        const cat = categories.find((c) => c.id === id);
        return {
          name: cat?.name ?? "Unknown",
          value: minutes,
          color: CHART_COLORS[categories.findIndex((c) => c.id === id) % CHART_COLORS.length],
        };
      })
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [tasks, categories]);

  // Heatmap: last 84 days (12 weeks)
  const heatmap = React.useMemo(() => {
    const weeks: { date: string; score: number; intensity: number }[][] = [];
    const today = new Date();
    const start = new Date(today);
    start.setDate(start.getDate() - 83);
    // Align to start of week (Sunday)
    while (start.getDay() !== 0) start.setDate(start.getDate() - 1);

    let cursor = new Date(start);
    while (cursor <= today) {
      const week: { date: string; score: number; intensity: number }[] = [];
      for (let d = 0; d < 7; d++) {
        const key = cursor.toISOString().slice(0, 10);
        const score = calculateDayScore(tasks, key, reviews[key], settings).finalScore;
        const hasData = tasks.some((t) => t.date === key) || !!reviews[key];
        week.push({
          date: key,
          score: hasData ? score : -1,
          intensity: hasData ? Math.min(1, score / 100) : 0,
        });
        cursor.setDate(cursor.getDate() + 1);
      }
      weeks.push(week);
    }
    return weeks;
  }, [tasks, reviews, settings]);

  // Stats
  const scoredDays = React.useMemo(
    () => last30.filter((d) => d.tasks > 0),
    [last30],
  );
  const avgScore = scoredDays.length > 0
    ? Math.round(scoredDays.reduce((a, b) => a + b.score, 0) / scoredDays.length)
    : 0;
  const bestDay = scoredDays.reduce((a, b) => (b.score > a.score ? b : a), scoredDays[0] ?? { date: "—", score: 0 });
  const worstDay = scoredDays.reduce((a, b) => (b.score < a.score && b.score > 0 ? b : a), scoredDays[0] ?? { date: "—", score: 0 });
  const totalCompleted = scoredDays.reduce((a, b) => a + b.completed, 0);
  const totalTasks = scoredDays.reduce((a, b) => a + b.tasks, 0);
  const completionRate = totalTasks > 0 ? Math.round((totalCompleted / totalTasks) * 100) : 0;

  // Most productive day of week
  const dayOfWeekStats = React.useMemo(() => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const sums = new Array(7).fill(0);
    const counts = new Array(7).fill(0);
    scoredDays.forEach((d) => {
      const dow = new Date(d.date + "T00:00:00").getDay();
      sums[dow] += d.score;
      counts[dow] += 1;
    });
    return days.map((name, i) => ({
      name,
      avg: counts[i] > 0 ? Math.round(sums[i] / counts[i]) : 0,
    }));
  }, [scoredDays]);

  const bestDow = dayOfWeekStats.reduce((a, b) => (b.avg > a.avg ? b : a), dayOfWeekStats[0]);

  return (
    <div className="space-y-4">
      <Tabs defaultValue="overview">
        <TabsList className="grid grid-cols-2 sm:grid-cols-4 w-full sm:w-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="heatmap">Heatmap</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4 space-y-4">
          {/* Stats grid */}
          <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
            <StatCard
              icon={<TrendingUp className="h-4 w-4 text-emerald-500" />}
              label="30-day Avg Score"
              value={avgScore}
              sub={scoreBand(avgScore).label}
              color={scoreBand(avgScore).color}
            />
            <StatCard
              icon={<Target className="h-4 w-4 text-blue-500" />}
              label="Completion Rate"
              value={`${completionRate}%`}
              sub={`${totalCompleted}/${totalTasks} tasks`}
            />
            <StatCard
              icon={<Flame className="h-4 w-4 text-orange-500" />}
              label="Best Streak"
              value={`${game.bestStreak}d`}
              sub={`Current: ${game.streak}d`}
            />
            <StatCard
              icon={<Award className="h-4 w-4 text-purple-500" />}
              label="Most Productive"
              value={bestDow.name}
              sub={`Avg ${bestDow.avg}`}
            />
          </div>

          {/* Score trend (30 days) */}
          <Card className="p-4 sm:p-5">
            <h3 className="text-sm font-semibold mb-3">Daily Score — Last 30 Days</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={last30}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis dataKey="label" tick={{ fontSize: 10 }} interval={4} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                    formatter={(value: number) => [`${value} / 100`, "Score"]}
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={{ r: 2 }}
                    activeDot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>

          {/* Best & worst */}
          <div className="grid sm:grid-cols-2 gap-4">
            <Card className="p-4 bg-emerald-500/5 border-emerald-500/30">
              <div className="flex items-center gap-2 mb-1">
                <Award className="h-4 w-4 text-emerald-500" />
                <h3 className="text-sm font-semibold">Best Day</h3>
              </div>
              <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{bestDay.score}</p>
              <p className="text-xs text-muted-foreground">{bestDay.date !== "—" ? new Date(bestDay.date + "T00:00:00").toLocaleDateString() : "—"}</p>
            </Card>
            <Card className="p-4 bg-red-500/5 border-red-500/30">
              <div className="flex items-center gap-2 mb-1">
                <Clock className="h-4 w-4 text-red-500" />
                <h3 className="text-sm font-semibold">Worst Day</h3>
              </div>
              <p className="text-2xl font-bold text-red-600 dark:text-red-400">{worstDay.score}</p>
              <p className="text-xs text-muted-foreground">{worstDay.date !== "—" ? new Date(worstDay.date + "T00:00:00").toLocaleDateString() : "—"}</p>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="mt-4 space-y-4">
          <Card className="p-4 sm:p-5">
            <h3 className="text-sm font-semibold mb-3">Weekly Average Score</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis dataKey="label" tick={{ fontSize: 10 }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                  />
                  <Bar dataKey="avg" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="p-4 sm:p-5">
            <h3 className="text-sm font-semibold mb-3">Completion Rate by Week (%)</h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis dataKey="label" tick={{ fontSize: 10 }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                  />
                  <Bar dataKey="completion" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="p-4 sm:p-5">
            <h3 className="text-sm font-semibold mb-3">Avg Score by Day of Week</h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dayOfWeekStats}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                  />
                  <Bar dataKey="avg" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="mt-4 space-y-4">
          <div className="grid lg:grid-cols-2 gap-4">
            <Card className="p-4 sm:p-5">
              <h3 className="text-sm font-semibold mb-3">Time Spent by Category</h3>
              {categoryData.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">
                  No data yet. Add tasks with time estimates.
                </div>
              ) : (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={90}
                        paddingAngle={2}
                      >
                        {categoryData.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ backgroundColor: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                        formatter={(value: number, name: string) => [`${Math.round(value / 60 * 10) / 10}h`, name]}
                      />
                      <Legend wrapperStyle={{ fontSize: 10 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>

            <Card className="p-4 sm:p-5">
              <h3 className="text-sm font-semibold mb-3">Category Breakdown</h3>
              {categoryData.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-12">No data yet.</p>
              ) : (
                <div className="space-y-2">
                  {categoryData.map((c, i) => {
                    const total = categoryData.reduce((a, b) => a + b.value, 0);
                    const pct = total > 0 ? Math.round((c.value / total) * 100) : 0;
                    return (
                      <div key={i} className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: c.color }} />
                            {c.name}
                          </span>
                          <span className="text-muted-foreground">
                            {Math.round(c.value / 60 * 10) / 10}h · {pct}%
                          </span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{ width: `${pct}%`, backgroundColor: c.color }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="heatmap" className="mt-4 space-y-4">
          <Card className="p-4 sm:p-5">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold">Activity Heatmap (12 weeks)</h3>
                <p className="text-xs text-muted-foreground">Darker green = higher score. Tap a cell to see the date.</p>
              </div>
              <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <span>Less</span>
                <span className="w-2.5 h-2.5 rounded-sm bg-muted" />
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500/30" />
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500/50" />
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500/70" />
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />
                <span>More</span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <div className="inline-flex gap-[3px]">
                {heatmap.map((week, wi) => (
                  <div key={wi} className="flex flex-col gap-[3px]">
                    {week.map((day) => {
                      const isEmpty = day.score < 0;
                      const bg = isEmpty
                        ? "bg-muted"
                        : day.score >= 95
                        ? "bg-emerald-500"
                        : day.score >= 85
                        ? "bg-emerald-500/80"
                        : day.score >= 70
                        ? "bg-emerald-500/60"
                        : day.score >= 50
                        ? "bg-emerald-500/40"
                        : day.score > 0
                        ? "bg-red-500/50"
                        : "bg-muted";
                      return (
                        <div
                          key={day.date}
                          className={`w-3 h-3 rounded-sm ${bg} hover:ring-1 hover:ring-emerald-500 transition`}
                          title={`${day.date}: ${isEmpty ? "no data" : day.score}`}
                        />
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  sub,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  sub?: string;
  color?: string;
}) {
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
        {icon}
      </div>
      <div className={`text-2xl font-bold ${color ?? ""}`}>{value}</div>
      {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
    </Card>
  );
}
