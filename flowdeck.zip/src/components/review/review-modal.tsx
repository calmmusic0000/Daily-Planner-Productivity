"use client";

import * as React from "react";
import { Star, Sparkles, Loader2, Check, AlertTriangle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { useStore } from "@/lib/store";
import { calculateDayScore, scoreBand, xpForDayScore } from "@/lib/score";
import type { DailyReview, Task, TaskStatus } from "@/lib/types";
import { toast } from "sonner";

interface ReviewModalProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  date?: string;
}

export function ReviewModal({ open, onOpenChange, date }: ReviewModalProps) {
  const tasks = useStore((s) => s.tasks);
  const reviews = useStore((s) => s.reviews);
  const settings = useStore((s) => s.settings);
  const saveReview = useStore((s) => s.saveReview);
  const awardXp = useStore((s) => s.awardXp);
  const _recomputeStreak = useStore((s) => s._recomputeStreak);

  const targetDate = date ?? new Date().toISOString().slice(0, 10);
  const existing = reviews[targetDate];

  const dayTasks = tasks.filter((t) => t.date === targetDate);

  // local form state
  const [form, setForm] = React.useState<DailyReview>({
    date: targetDate,
    wentWell: "",
    didNotGoWell: "",
    biggestDistraction: "",
    mood: 5,
    energy: 5,
    sleepHours: 7,
    waterIntake: 6,
    exerciseDone: false,
    readingDone: false,
    achievement: "",
    tomorrowFocus: "",
    submittedAt: 0,
  });

  React.useEffect(() => {
    if (open) {
      if (existing) {
        setForm(existing);
      } else {
        setForm({
          date: targetDate,
          wentWell: "",
          didNotGoWell: "",
          biggestDistraction: "",
          mood: 5,
          energy: 5,
          sleepHours: 7,
          waterIntake: 6,
          exerciseDone: false,
          readingDone: false,
          achievement: "",
          tomorrowFocus: "",
          submittedAt: 0,
        });
      }
    }
  }, [open, existing, targetDate]);

  const previewScore = React.useMemo(
    () => calculateDayScore(tasks, targetDate, form, settings),
    [tasks, targetDate, form, settings],
  );
  const band = scoreBand(previewScore.finalScore);

  // AI analysis state
  const [aiInsight, setAiInsight] = React.useState<string | null>(existing ? null : null);
  const [aiLoading, setAiLoading] = React.useState(false);
  const [aiError, setAiError] = React.useState<string | null>(null);

  const handleSave = () => {
    const review: DailyReview = { ...form, submittedAt: Date.now() };
    saveReview(review);
    // Award XP for completing review + day-score bonus (one-time per day via review)
    const bonus = xpForDayScore(previewScore.finalScore);
    awardXp(50 + bonus); // 50 base + score-based bonus
    _recomputeStreak();
    toast.success(`Review saved! +${50 + bonus} XP`);
    onOpenChange(false);
  };

  const runAi = async () => {
    setAiLoading(true);
    setAiError(null);
    setAiInsight(null);
    try {
      const res = await fetch("/api/ai-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date: targetDate,
          tasks: dayTasks,
          review: form,
          score: previewScore,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setAiInsight(data.insight || "No insight returned.");
    } catch (e) {
      setAiError(e instanceof Error ? e.message : "Failed to fetch AI analysis");
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nightly Review — {new Date(targetDate + "T00:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" })}</DialogTitle>
          <DialogDescription>
            Did you finish these? Score your day and reflect.
          </DialogDescription>
        </DialogHeader>

        {/* Task status quick-mark */}
        {dayTasks.length > 0 && (
          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wide text-muted-foreground">
              Tasks ({dayTasks.length})
            </Label>
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {dayTasks
                .sort((a, b) => (a.startTime ?? "z").localeCompare(b.startTime ?? "z"))
                .map((t) => (
                  <TaskStatusRow key={t.id} task={t} />
                ))}
            </div>
          </div>
        )}

        {/* Reflection fields */}
        <div className="grid gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="wentWell">What went well?</Label>
            <Textarea
              id="wentWell"
              rows={2}
              placeholder="Finished KDP research, hit workout..."
              value={form.wentWell}
              onChange={(e) => setForm((f) => ({ ...f, wentWell: e.target.value }))}
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="didNotGoWell">What didn&apos;t go well?</Label>
            <Textarea
              id="didNotGoWell"
              rows={2}
              placeholder="Cover design took longer than expected..."
              value={form.didNotGoWell}
              onChange={(e) => setForm((f) => ({ ...f, didNotGoWell: e.target.value }))}
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="distraction">Biggest distraction</Label>
            <Input
              id="distraction"
              placeholder="Social media, phone notifications..."
              value={form.biggestDistraction}
              onChange={(e) => setForm((f) => ({ ...f, biggestDistraction: e.target.value }))}
            />
          </div>

          {/* Sliders */}
          <div className="grid sm:grid-cols-2 gap-4">
            <SliderRow
              label="Mood"
              value={form.mood}
              min={1}
              max={10}
              onChange={(v) => setForm((f) => ({ ...f, mood: v }))}
              icon={<Star className="h-3.5 w-3.5" />}
            />
            <SliderRow
              label="Energy"
              value={form.energy}
              min={1}
              max={10}
              onChange={(v) => setForm((f) => ({ ...f, energy: v }))}
              icon={<Sparkles className="h-3.5 w-3.5" />}
            />
            <SliderRow
              label="Sleep (hours)"
              value={form.sleepHours}
              min={0}
              max={12}
              step={0.5}
              onChange={(v) => setForm((f) => ({ ...f, sleepHours: v }))}
            />
            <SliderRow
              label="Water (glasses)"
              value={form.waterIntake}
              min={0}
              max={15}
              onChange={(v) => setForm((f) => ({ ...f, waterIntake: v }))}
            />
          </div>

          {/* Toggle rows */}
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="flex items-center justify-between p-3 rounded-md border">
              <Label htmlFor="ex" className="text-sm">Exercise completed?</Label>
              <Switch
                id="ex"
                checked={form.exerciseDone}
                onCheckedChange={(v) => setForm((f) => ({ ...f, exerciseDone: v }))}
              />
            </div>
            <div className="flex items-center justify-between p-3 rounded-md border">
              <Label htmlFor="rd" className="text-sm">Reading completed?</Label>
              <Switch
                id="rd"
                checked={form.readingDone}
                onCheckedChange={(v) => setForm((f) => ({ ...f, readingDone: v }))}
              />
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="ach">Today&apos;s achievement</Label>
            <Input
              id="ach"
              placeholder="Published my first KDP book..."
              value={form.achievement}
              onChange={(e) => setForm((f) => ({ ...f, achievement: e.target.value }))}
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="tf">Tomorrow&apos;s focus</Label>
            <Textarea
              id="tf"
              rows={2}
              placeholder="Wake at 6, design 3 covers, write 500 words..."
              value={form.tomorrowFocus}
              onChange={(e) => setForm((f) => ({ ...f, tomorrowFocus: e.target.value }))}
            />
          </div>
        </div>

        {/* Score preview */}
        <Card className="p-3 bg-muted/30">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-muted-foreground uppercase tracking-wide">Predicted Score</div>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className={`text-3xl font-bold ${band.color}`}>{previewScore.finalScore}</span>
                <Badge variant="secondary" className={band.color}>{band.label}</Badge>
              </div>
            </div>
            <div className="text-right text-xs space-y-0.5">
              <div>Completed: <span className="font-semibold">{previewScore.breakdown.completed}/60</span></div>
              <div>Priority: <span className="font-semibold">{previewScore.breakdown.priority}/20</span></div>
              <div>Habits: <span className="font-semibold">{previewScore.breakdown.habits}/10</span></div>
              <div>Time: <span className="font-semibold">{previewScore.breakdown.time}/10</span></div>
            </div>
          </div>
        </Card>

        {/* AI Coach */}
        <div className="space-y-2">
          <Button
            variant="outline"
            onClick={runAi}
            disabled={aiLoading}
            className="w-full"
          >
            {aiLoading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Analyzing your day...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2 text-emerald-500" />
                Get AI Coaching Insight
              </>
            )}
          </Button>
          {aiError && (
            <div className="flex items-start gap-2 p-3 rounded-md border border-red-500/30 bg-red-500/5 text-sm">
              <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-red-600 dark:text-red-400">AI analysis failed</p>
                <p className="text-xs text-muted-foreground mt-0.5">{aiError}</p>
              </div>
            </div>
          )}
          {aiInsight && (
            <Card className="p-4 bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
              <div className="flex items-start gap-2">
                <Sparkles className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-emerald-600 dark:text-emerald-400 mb-1">AI Coach</p>
                  <div className="text-sm whitespace-pre-wrap leading-relaxed">{aiInsight}</div>
                </div>
              </div>
            </Card>
          )}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700 text-white">
            <Check className="h-4 w-4 mr-1" />
            Save Review
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function SliderRow({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
  icon,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  icon?: React.ReactNode;
}) {
  return (
    <div className="grid gap-1.5 p-3 rounded-md border">
      <div className="flex items-center justify-between text-sm">
        <Label className="flex items-center gap-1.5">
          {icon}
          {label}
        </Label>
        <span className="font-semibold text-emerald-600 dark:text-emerald-400">{value}</span>
      </div>
      <Slider value={[value]} min={min} max={max} step={step} onValueChange={(v) => onChange(v[0])} />
    </div>
  );
}

function TaskStatusRow({ task }: { task: Task }) {
  const setTaskStatus = useStore((s) => s.setTaskStatus);
  const statuses: TaskStatus[] = ["pending", "completed", "partial", "missed"];
  const labels: Record<TaskStatus, string> = {
    pending: "Pending",
    completed: "Yes",
    partial: "Partial",
    missed: "No",
  };
  const colors: Record<TaskStatus, string> = {
    pending: "bg-slate-500/10 text-slate-600 dark:text-slate-300 border-slate-500/30",
    completed: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
    partial: "bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30",
    missed: "bg-red-500/15 text-red-600 dark:text-red-400 border-red-500/30",
  };
  return (
    <div className="flex items-center gap-2 p-2 rounded-md border bg-card">
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium truncate">{task.title}</div>
        {task.startTime && (
          <div className="text-[10px] text-muted-foreground">{task.startTime}{task.endTime ? `–${task.endTime}` : ""}</div>
        )}
      </div>
      <div className="flex gap-1">
        {statuses.map((s) => (
          <button
            key={s}
            onClick={() => setTaskStatus(task.id, s)}
            className={`text-[10px] px-2 py-1 rounded border transition ${
              task.status === s
                ? colors[s]
                : "border-transparent text-muted-foreground hover:bg-muted"
            }`}
          >
            {labels[s]}
          </button>
        ))}
      </div>
    </div>
  );
}
