"use client";

import * as React from "react";
import {
  Flame,
  Trophy,
  TrendingUp,
  Target,
  Quote,
  AlertCircle,
  Calendar as CalendarIcon,
  Zap,
  Sparkles,
  Clock,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/store";
import { calculateDayScore, scoreBand, levelForXp, rankTitle, xpForDayScore } from "@/lib/score";
import { quoteOfTheDay, dailyQuoteSeed } from "@/lib/quotes";
import { TaskList } from "@/components/tasks/task-list";
import { NewTaskButton } from "@/components/tasks/task-form";
import { useSeedDemo } from "@/lib/seed";
import type { DayScore } from "@/lib/types";

interface DashboardProps {
  onNavigate: (tab: string) => void;
  onOpenReview: () => void;
}

export function Dashboard({ onNavigate, onOpenReview }: DashboardProps) {
  const tasks = useStore((s) => s.tasks);
  const reviews = useStore((s) => s.reviews);
  const settings = useStore((s) => s.settings);
  const game = useStore((s) => s.game);
  const awardXp = useStore((s) => s.awardXp);

  const today = new Date().toISOString().slice(0, 10);
  const tomorrowDate = new Date();
  tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  const tomorrow = tomorrowDate.toISOString().slice(0, 10);

  const todayTasks = tasks.filter((t) => t.date === today);
  const tomorrowTasks = tasks.filter((t) => t.date === tomorrow);
  const todayReview = reviews[today];

  const score: DayScore = React.useMemo(
    () => calculateDayScore(tasks, today, todayReview, settings),
    [tasks, today, todayReview, settings],
  );
  const band = scoreBand(score.finalScore);

  // Upcoming reminder: next task in the future
  const now = new Date();
  const upcoming = todayTasks
    .filter((t) => t.startTime && t.status === "pending")
    .map((t) => ({ ...t, startDt: new Date(`${t.date}T${t.startTime}:00`) }))
    .filter((t) => t.startDt > now)
    .sort((a, b) => a.startDt.getTime() - b.startDt.getTime())[0];

  const missed = todayTasks.filter(
    (t) => t.status === "missed" || (t.status === "pending" && t.startTime && new Date(`${t.date}T${t.startTime}:00`) < now),
  );

  const completedToday = todayTasks.filter((t) => t.status === "completed").length;
  const completionPct = todayTasks.length > 0 ? (completedToday / todayTasks.length) * 100 : 0;

  const quote = quoteOfTheDay(dailyQuoteSeed());

  const lvl = levelForXp(game.xp);
  const seedDemo = useSeedDemo();

  // XP reward for review (one-time per day)
  const [reviewXpAwarded, setReviewXpAwarded] = React.useState<string | null>(null);
  React.useEffect(() => {
    if (todayReview && reviewXpAwarded !== today && score.finalScore > 0) {
      // Note: this just visualizes — actual XP award happens on review submit
      setReviewXpAwarded(today);
    }
  }, [todayReview, today, score.finalScore, reviewXpAwarded]);

  return (
    <div className="space-y-5">
      {/* Hero stats row */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        {/* Today's Score */}
        <Card className="p-4 sm:p-5 col-span-2 lg:col-span-1 relative overflow-hidden">
          <div className={`absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl opacity-20 ${band.bg}`} />
          <div className="relative">
            <div className="flex items-center justify-between">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Today&apos;s Score</p>
              <Trophy className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className={`text-4xl font-bold ${band.color}`}>{score.finalScore}</span>
              <span className="text-sm text-muted-foreground">/ 100</span>
            </div>
            <Badge variant="secondary" className={`mt-1 ${band.color} bg-transparent`}>
              {band.label}
            </Badge>
          </div>
        </Card>

        {/* Streak */}
        <Card className="p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Current Streak</p>
            <Flame className="h-4 w-4 text-orange-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-4xl font-bold">{game.streak}</span>
            <span className="text-sm text-muted-foreground">days</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">Best: {game.bestStreak} days</p>
        </Card>

        {/* Level / XP */}
        <Card className="p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Level</p>
            <Zap className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-4xl font-bold">{lvl.level}</span>
            <span className="text-sm text-muted-foreground">{rankTitle(lvl.level)}</span>
          </div>
          <div className="mt-2">
            <Progress value={lvl.pct} className="h-1.5" />
            <p className="text-xs text-muted-foreground mt-1">
              {lvl.intoLevel}/{lvl.neededForNext} XP
            </p>
          </div>
        </Card>

        {/* Completion */}
        <Card className="p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Done Today</p>
            <Target className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-4xl font-bold">{completedToday}</span>
            <span className="text-sm text-muted-foreground">/ {todayTasks.length}</span>
          </div>
          <Progress value={completionPct} className="h-1.5 mt-2" />
        </Card>
      </div>

      {/* Quote */}
      <Card className="p-4 sm:p-5 bg-gradient-to-r from-emerald-500/5 to-cyan-500/5 border-emerald-500/20">
        <div className="flex items-start gap-3">
          <Quote className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm sm:text-base italic">&ldquo;{quote.text}&rdquo;</p>
            <p className="text-xs text-muted-foreground mt-1">— {quote.author}</p>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Today's Tasks */}
        <Card className="p-4 sm:p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-base sm:text-lg font-semibold">Today&apos;s Tasks</h2>
              <p className="text-xs text-muted-foreground">
                {new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
              </p>
            </div>
            <NewTaskButton defaultDate={today} />
          </div>
          {todayTasks.length === 0 && tasks.length === 0 ? (
            <EmptyDashboard onSeed={seedDemo} />
          ) : (
            <TaskList tasks={todayTasks} emptyHint="No tasks scheduled today. Tap 'New Task' to plan your day." />
          )}
        </Card>

        {/* Sidebar: upcoming + missed + quick actions */}
        <div className="space-y-4">
          {/* Upcoming reminder */}
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-blue-500" />
              <h3 className="text-sm font-semibold">Up Next</h3>
            </div>
            {upcoming ? (
              <div>
                <p className="text-sm font-medium">{upcoming.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Starts at {upcoming.startTime}
                  {" — "}
                  {Math.round((upcoming.startDt.getTime() - now.getTime()) / 60000)} min
                </p>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">No upcoming tasks today.</p>
            )}
          </Card>

          {/* Missed tasks */}
          {missed.length > 0 && (
            <Card className="p-4 border-red-500/30 bg-red-500/5">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="h-4 w-4 text-red-500" />
                <h3 className="text-sm font-semibold">Missed / Overdue</h3>
                <Badge variant="destructive" className="ml-auto">{missed.length}</Badge>
              </div>
              <div className="space-y-1">
                {missed.slice(0, 5).map((t) => (
                  <div key={t.id} className="flex items-center justify-between text-xs">
                    <span className="line-through text-muted-foreground">{t.title}</span>
                    <span className="text-muted-foreground">{t.startTime}</span>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Tomorrow preview */}
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <CalendarIcon className="h-4 w-4 text-purple-500" />
              <h3 className="text-sm font-semibold">Tomorrow</h3>
              <Badge variant="secondary" className="ml-auto">{tomorrowTasks.length}</Badge>
            </div>
            {tomorrowTasks.length > 0 ? (
              <div className="space-y-1">
                {tomorrowTasks.slice(0, 5).map((t) => (
                  <div key={t.id} className="flex items-center justify-between text-xs">
                    <span>{t.title}</span>
                    <span className="text-muted-foreground">{t.startTime ?? "—"}</span>
                  </div>
                ))}
                {tomorrowTasks.length > 5 && (
                  <Button variant="ghost" size="sm" className="w-full text-xs" onClick={() => onNavigate("tasks")}>
                    View all
                  </Button>
                )}
              </div>
            ) : (
              <Button
                variant="outline"
                size="sm"
                className="w-full text-xs"
                onClick={() => onNavigate("tasks")}
              >
                Plan tomorrow →
              </Button>
            )}
          </Card>

          {/* Nightly review CTA */}
          <Card className="p-4 bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-4 w-4 text-emerald-500" />
              <h3 className="text-sm font-semibold">Nightly Review</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-3">
              {todayReview
                ? "Today's review submitted. Tap to update."
                : "End your day by scoring your tasks and reflecting."}
            </p>
            <Button
              onClick={onOpenReview}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              size="sm"
            >
              {todayReview ? "Update Review" : "Start Review"}
            </Button>
          </Card>
        </div>
      </div>

      {/* Weekly progress strip */}
      <WeeklyStrip />
    </div>
  );
}

function WeeklyStrip() {
  const tasks = useStore((s) => s.tasks);
  const reviews = useStore((s) => s.reviews);
  const settings = useStore((s) => s.settings);

  const days = React.useMemo(() => {
    const arr: { date: string; label: string; score: number; tasks: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      const score = calculateDayScore(tasks, key, reviews[key], settings).finalScore;
      const dayTasks = tasks.filter((t) => t.date === key).length;
      arr.push({
        date: key,
        label: d.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 1),
        score,
        tasks: dayTasks,
      });
    }
    return arr;
  }, [tasks, reviews, settings]);

  const avg = Math.round(days.reduce((a, d) => a + d.score, 0) / days.length);

  return (
    <Card className="p-4 sm:p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-emerald-500" />
          <h3 className="text-sm font-semibold">Weekly Progress</h3>
        </div>
        <span className="text-xs text-muted-foreground">7-day avg: <span className="font-semibold text-foreground">{avg}</span></span>
      </div>
      <div className="flex items-end justify-between gap-2 h-24">
        {days.map((d) => {
          const h = Math.max(8, (d.score / 100) * 100);
          const band = scoreBand(d.score);
          return (
            <div key={d.date} className="flex-1 flex flex-col items-center gap-1">
              <div className="text-[10px] text-muted-foreground">{d.score || "–"}</div>
              <div
                className={`w-full rounded-t-md ${band.bg} opacity-90 hover:opacity-100 transition`}
                style={{ height: `${h}%` }}
                title={`${d.date}: ${d.score}`}
              />
              <div className="text-xs text-muted-foreground">{d.label}</div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function EmptyDashboard({ onSeed }: { onSeed: () => void }) {
  return (
    <div className="text-center py-12 px-4 border border-dashed rounded-lg">
      <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-emerald-500/15 flex items-center justify-center">
        <Sparkles className="h-5 w-5 text-emerald-500" />
      </div>
      <h3 className="text-sm font-semibold mb-1">Plan your first day</h3>
      <p className="text-xs text-muted-foreground mb-4 max-w-sm mx-auto">
        Start by adding tasks for today, or load the example routine (Wake up, Workout, Vocabulary, KDP Research...) to see how it works.
      </p>
      <div className="flex items-center justify-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={onSeed}
        >
          <Sparkles className="h-3.5 w-3.5 mr-1" />
          Load Example Routine
        </Button>
      </div>
    </div>
  );
}

