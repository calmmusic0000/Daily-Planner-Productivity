"use client";

import * as React from "react";
import { Plus, Pencil, Copy, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/store";
import type { Task, Priority, RepeatRule } from "@/lib/types";
import { PRIORITY_META, colorOf } from "@/lib/types";
import { toast } from "sonner";

interface TaskFormProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editingTask?: Task | null;
  defaultDate?: string; // YYYY-MM-DD
}

const PRIORITIES: Priority[] = ["low", "medium", "high", "urgent"];
const REPEATS: RepeatRule[] = ["none", "daily", "weekly", "monthly"];

export function TaskForm({ open, onOpenChange, editingTask, defaultDate }: TaskFormProps) {
  const categories = useStore((s) => s.categories);
  const addTask = useStore((s) => s.addTask);
  const updateTask = useStore((s) => s.updateTask);

  const today = defaultDate ?? new Date().toISOString().slice(0, 10);

  const [title, setTitle] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [date, setDate] = React.useState(today);
  const [startTime, setStartTime] = React.useState("");
  const [endTime, setEndTime] = React.useState("");
  const [estimatedMin, setEstimatedMin] = React.useState("");
  const [priority, setPriority] = React.useState<Priority>("medium");
  const [categoryId, setCategoryId] = React.useState(categories[0]?.id ?? "personal");
  const [tags, setTags] = React.useState<string>("");
  const [repeat, setRepeat] = React.useState<RepeatRule>("none");

  React.useEffect(() => {
    if (open) {
      if (editingTask) {
        setTitle(editingTask.title);
        setNotes(editingTask.notes ?? "");
        setDate(editingTask.date);
        setStartTime(editingTask.startTime ?? "");
        setEndTime(editingTask.endTime ?? "");
        setEstimatedMin(editingTask.estimatedMin?.toString() ?? "");
        setPriority(editingTask.priority);
        setCategoryId(editingTask.categoryId);
        setTags(editingTask.tags.join(", "));
        setRepeat(editingTask.repeat);
      } else {
        setTitle("");
        setNotes("");
        setDate(defaultDate ?? today);
        setStartTime("");
        setEndTime("");
        setEstimatedMin("");
        setPriority("medium");
        setCategoryId(categories[0]?.id ?? "personal");
        setTags("");
        setRepeat("none");
      }
    }
  }, [open, editingTask, defaultDate, today, categories]);

  const handleSubmit = () => {
    if (!title.trim()) {
      toast.error("Title is required");
      return;
    }
    const tagList = tags
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);
    const payload = {
      title: title.trim(),
      notes: notes.trim() || undefined,
      date,
      startTime: startTime || undefined,
      endTime: endTime || undefined,
      estimatedMin: estimatedMin ? parseInt(estimatedMin, 10) : undefined,
      priority,
      categoryId,
      tags: tagList,
      repeat,
    };
    if (editingTask) {
      updateTask(editingTask.id, payload);
      toast.success("Task updated");
    } else {
      addTask(payload);
      toast.success("Task added");
      // Auto-create repeat occurrences
      if (repeat !== "none") {
        const base = new Date(date);
        const steps = repeat === "daily" ? 7 : repeat === "weekly" ? 4 : 3;
        const inc = repeat === "daily" ? 1 : repeat === "weekly" ? 7 : 30;
        for (let i = 1; i <= steps; i++) {
          const d = new Date(base);
          d.setDate(d.getDate() + inc * i);
          addTask({ ...payload, date: d.toISOString().slice(0, 10) });
        }
        toast.info(`Created ${steps + 1} ${repeat} occurrences`);
      }
    }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[520px] max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editingTask ? "Edit Task" : "New Task"}</DialogTitle>
          <DialogDescription>
            {editingTask
              ? "Update the details below."
              : "Plan tomorrow tonight — fill in the details and save."}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="grid gap-1.5">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              placeholder="e.g. Amazon KDP Research"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="date">Date</Label>
              <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="repeat">Repeat</Label>
              <Select value={repeat} onValueChange={(v) => setRepeat(v as RepeatRule)}>
                <SelectTrigger id="repeat">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {REPEATS.map((r) => (
                    <SelectItem key={r} value={r} className="capitalize">
                      {r === "none" ? "One-time" : `Repeat ${r}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="start">Start</Label>
              <Input id="start" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="end">End</Label>
              <Input id="end" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="est">Est. min</Label>
              <Input
                id="est"
                type="number"
                inputMode="numeric"
                placeholder="60"
                value={estimatedMin}
                onChange={(e) => setEstimatedMin(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label>Priority</Label>
              <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => (
                    <SelectItem key={p} value={p}>
                      <span className={PRIORITY_META[p].color}>●</span> {PRIORITY_META[p].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label>Category</Label>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      <span className={`inline-block w-2 h-2 rounded-full mr-2 ${colorOf(c.color).dot}`} />
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              placeholder="kdp, books, research"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
            />
            {tags.trim() && (
              <div className="flex flex-wrap gap-1 mt-1">
                {tags.split(",").map((t, i) => (
                  <Badge key={i} variant="secondary" className="text-xs">
                    {t.trim()}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Any extra context..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-emerald-600 hover:bg-emerald-700 text-white">
            {editingTask ? "Save Changes" : "Create Task"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Row actions for tasks (edit/duplicate/delete)
export function TaskRowActions({ task }: { task: Task }) {
  const [editOpen, setEditOpen] = React.useState(false);
  const duplicateTask = useStore((s) => s.duplicateTask);
  const deleteTask = useStore((s) => s.deleteTask);

  return (
    <>
      <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition">
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={() => setEditOpen(true)}
          title="Edit"
        >
          <Pencil className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={() => {
            duplicateTask(task.id);
            toast.success("Task duplicated");
          }}
          title="Duplicate"
        >
          <Copy className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 text-red-500 hover:text-red-600"
          onClick={() => {
            deleteTask(task.id);
            toast.success("Task deleted");
          }}
          title="Delete"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
      <TaskForm open={editOpen} onOpenChange={setEditOpen} editingTask={task} />
    </>
  );
}

// Floating "new task" button
export function NewTaskButton({ defaultDate }: { defaultDate?: string }) {
  const [open, setOpen] = React.useState(false);
  return (
    <>
      <Button
        onClick={() => setOpen(true)}
        className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
      >
        <Plus className="h-4 w-4 mr-1" />
        New Task
      </Button>
      <TaskForm open={open} onOpenChange={setOpen} defaultDate={defaultDate} />
    </>
  );
}
