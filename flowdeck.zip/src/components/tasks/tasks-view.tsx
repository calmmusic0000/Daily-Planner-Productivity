"use client";

import * as React from "react";
import { ChevronLeft, ChevronRight, CalendarDays, Filter, Sparkles } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { NewTaskButton } from "@/components/tasks/task-form";
import { TaskList } from "@/components/tasks/task-list";
import { useStore } from "@/lib/store";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { calculateDayScore, scoreBand } from "@/lib/score";
import type { Priority } from "@/lib/types";

interface TasksViewProps {
  onOpenReview: (date: string) => void;
}

const PRIORITIES: (Priority | "all")[] = ["all", "urgent", "high", "medium", "low"];

export function TasksView({ onOpenReview }: TasksViewProps) {
  const tasks = useStore((s) => s.tasks);
  const reviews = useStore((s) => s.reviews);
  const settings = useStore((s) => s.settings);
  const categories = useStore((s) => s.categories);

  const [selectedDate, setSelectedDate] = React.useState(
    new Date().toISOString().slice(0, 10),
  );
  const [filterPriority, setFilterPriority] = React.useState<Priority | "all">("all");
  const [filterCategory, setFilterCategory] = React.useState<string>("all");

  const dayTasks = React.useMemo(() => {
    return tasks.filter((t) => {
      if (t.date !== selectedDate) return false;
      if (filterPriority !== "all" && t.priority !== filterPriority) return false;
      if (filterCategory !== "all" && t.categoryId !== filterCategory) return false;
      return true;
    });
  }, [tasks, selectedDate, filterPriority, filterCategory]);

  const review = reviews[selectedDate];
  const score = calculateDayScore(tasks, selectedDate, review, settings);
  const band = scoreBand(score.finalScore);

  const shiftDate = (days: number) => {
    const d = new Date(selectedDate + "T00:00:00");
    d.setDate(d.getDate() + days);
    setSelectedDate(d.toISOString().slice(0, 10));
  };

  const isToday = selectedDate === new Date().toISOString().slice(0, 10);
  const dateLabel = new Date(selectedDate + "T00:00:00").toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  });

  return (
    <div className="space-y-4">
      {/* Date navigator */}
      <Card className="p-3 sm:p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => shiftDate(-1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="text-center min-w-[180px]">
              <div className="text-sm font-semibold">{dateLabel}</div>
              {isToday && (
                <Badge variant="secondary" className="text-[10px] mt-0.5">Today</Badge>
              )}
            </div>
            <Button variant="outline" size="icon" onClick={() => shiftDate(1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedDate(new Date().toISOString().slice(0, 10))}
              className="ml-1"
            >
              <CalendarDays className="h-4 w-4 mr-1" />
              Today
            </Button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">
              Day Score: <span className={`font-bold ${band.color}`}>{score.finalScore}</span>
            </span>
            <NewTaskButton defaultDate={selectedDate} />
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2 mt-3 pt-3 border-t">
          <span className="text-xs text-muted-foreground inline-flex items-center gap-1">
            <Filter className="h-3 w-3" /> Filter:
          </span>
          <Select value={filterPriority} onValueChange={(v) => setFilterPriority(v as Priority | "all")}>
            <SelectTrigger className="h-8 w-[120px] text-xs">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              {PRIORITIES.map((p) => (
                <SelectItem key={p} value={p} className="text-xs capitalize">
                  {p === "all" ? "All priorities" : p}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="h-8 w-[140px] text-xs">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all" className="text-xs">All categories</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c.id} value={c.id} className="text-xs">
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            variant="outline"
            size="sm"
            className="ml-auto h-8 text-xs"
            onClick={() => onOpenReview(selectedDate)}
          >
            <Sparkles className="h-3 w-3 mr-1" />
            {review ? "Update Review" : "Nightly Review"}
          </Button>
        </div>
      </Card>

      {/* Tasks for the day */}
      <TaskList tasks={dayTasks} emptyHint="No tasks for this day. Tap 'New Task' to add one." />

      {/* Day summary */}
      {dayTasks.length > 0 && (
        <Card className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-emerald-500">{score.completedTasks}</div>
            <div className="text-xs text-muted-foreground">Completed</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-amber-500">{score.partialTasks}</div>
            <div className="text-xs text-muted-foreground">Partial</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-red-500">{score.missedTasks}</div>
            <div className="text-xs text-muted-foreground">Missed</div>
          </div>
          <div>
            <div className={`text-2xl font-bold ${band.color}`}>{score.finalScore}</div>
            <div className="text-xs text-muted-foreground">Score</div>
          </div>
        </Card>
      )}
    </div>
  );
}
