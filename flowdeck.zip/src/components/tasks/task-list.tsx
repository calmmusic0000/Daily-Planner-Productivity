"use client";

import * as React from "react";
import { Clock, Tag, Flag } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useStore } from "@/lib/store";
import type { Task } from "@/lib/types";
import { PRIORITY_META, colorOf } from "@/lib/types";
import { TaskRowActions } from "./task-form";

interface TaskItemProps {
  task: Task;
  showDate?: boolean;
  compact?: boolean;
}

export function TaskItem({ task, showDate = false, compact = false }: TaskItemProps) {
  const setTaskStatus = useStore((s) => s.setTaskStatus);
  const categories = useStore((s) => s.categories);

  const category = categories.find((c) => c.id === task.categoryId);
  const color = colorOf(category?.color ?? "slate");
  const isDone = task.status === "completed";
  const isPartial = task.status === "partial";
  const isMissed = task.status === "missed";

  const cycleStatus = () => {
    const order: Task["status"][] = ["pending", "completed", "partial", "missed"];
    const idx = order.indexOf(task.status);
    setTaskStatus(task.id, order[(idx + 1) % order.length]);
  };

  return (
    <Card
      className={`group relative p-3 sm:p-4 hover:shadow-md transition-all border-l-4 ${color.border} ${
        isDone ? "opacity-60" : ""
      } ${isMissed ? "opacity-50" : ""}`}
    >
      <div className="flex items-start gap-3">
        <button
          onClick={cycleStatus}
          className="mt-0.5 shrink-0"
          title="Click to cycle: pending → completed → partial → missed"
          aria-label="Toggle task status"
        >
          <span
            className={`flex items-center justify-center w-5 h-5 rounded-full border-2 transition-all ${
              isDone
                ? "bg-emerald-500 border-emerald-500 text-white"
                : isPartial
                ? "bg-amber-500 border-amber-500 text-white"
                : isMissed
                ? "bg-red-500 border-red-500 text-white"
                : "border-slate-300 dark:border-slate-600"
            }`}
          >
            {isDone && (
              <svg viewBox="0 0 12 12" className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M2 6l3 3 5-6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            )}
            {isPartial && <span className="text-[10px] font-bold">/</span>}
            {isMissed && (
              <svg viewBox="0 0 12 12" className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 3l6 6M9 3l-6 6" strokeLinecap="round" />
              </svg>
            )}
          </span>
        </button>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3
              className={`text-sm sm:text-base font-medium leading-snug ${
                isDone ? "line-through text-muted-foreground" : ""
              }`}
            >
              {task.title}
            </h3>
            <TaskRowActions task={task} />
          </div>

          {!compact && (
            <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-muted-foreground">
              {task.startTime && (
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {task.startTime}
                  {task.endTime ? `–${task.endTime}` : ""}
                </span>
              )}
              {showDate && (
                <span className="inline-flex items-center gap-1">
                  {new Date(task.date + "T00:00:00").toLocaleDateString(undefined, {
                    month: "short",
                    day: "numeric",
                  })}
                </span>
              )}
              {category && (
                <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded ${color.soft} ${color.text}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${color.dot}`} />
                  {category.name}
                </span>
              )}
              <span className={`inline-flex items-center gap-1 ${PRIORITY_META[task.priority].color}`}>
                <Flag className="h-3 w-3" />
                {PRIORITY_META[task.priority].label}
              </span>
              {task.estimatedMin && (
                <span className="inline-flex items-center gap-1">
                  ~{task.estimatedMin}m
                </span>
              )}
              {task.tags.length > 0 && (
                <span className="inline-flex items-center gap-1">
                  <Tag className="h-3 w-3" />
                  {task.tags.join(", ")}
                </span>
              )}
            </div>
          )}

          {!compact && task.notes && (
            <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2">{task.notes}</p>
          )}
        </div>
      </div>
    </Card>
  );
}

export function TaskList({
  tasks,
  emptyHint = "No tasks yet. Add one to start planning.",
  showDate = false,
}: {
  tasks: Task[];
  emptyHint?: string;
  showDate?: boolean;
}) {
  if (tasks.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground text-sm border border-dashed rounded-lg">
        {emptyHint}
      </div>
    );
  }
  // Sort by start time (none last), then by priority weight, then by order
  const sorted = [...tasks].sort((a, b) => {
    if (a.startTime && b.startTime) return a.startTime.localeCompare(b.startTime);
    if (a.startTime) return -1;
    if (b.startTime) return 1;
    const pw = PRIORITY_META[b.priority].weight - PRIORITY_META[a.priority].weight;
    if (pw !== 0) return pw;
    return a.order - b.order;
  });
  return (
    <div className="space-y-2">
      {sorted.map((t) => (
        <TaskItem key={t.id} task={t} showDate={showDate} />
      ))}
    </div>
  );
}
