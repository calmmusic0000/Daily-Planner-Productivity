"use client";

import * as React from "react";
import { Zap, Trophy, Flame, Star, Award, Target, Crown, Medal } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useStore } from "@/lib/store";
import { levelForXp, rankTitle, xpForDayScore } from "@/lib/score";

interface AchievementDef {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  check: (s: { tasks: number; completed: number; reviews: number; streak: number; bestStreak: number; level: number }) => boolean;
}

const ACHIEVEMENTS: AchievementDef[] = [
  { id: "first-task", title: "First Step", description: "Complete your first task", icon: <Star className="h-5 w-5" />, check: (s) => s.completed >= 1 },
  { id: "ten-tasks", title: "Getting Going", description: "Complete 10 tasks", icon: <Target className="h-5 w-5" />, check: (s) => s.completed >= 10 },
  { id: "fifty-tasks", title: "Half Century", description: "Complete 50 tasks", icon: <Medal className="h-5 w-5" />, check: (s) => s.completed >= 50 },
  { id: "hundred-tasks", title: "Centurion", description: "Complete 100 tasks", icon: <Award className="h-5 w-5" />, check: (s) => s.completed >= 100 },
  { id: "first-review", title: "Self-Aware", description: "Submit your first nightly review", icon: <Trophy className="h-5 w-5" />, check: (s) => s.reviews >= 1 },
  { id: "seven-reviews", title: "Week Warrior", description: "Submit 7 nightly reviews", icon: <Crown className="h-5 w-5" />, check: (s) => s.reviews >= 7 },
  { id: "streak-3", title: "Hat Trick", description: "3-day streak", icon: <Flame className="h-5 w-5" />, check: (s) => s.bestStreak >= 3 },
  { id: "streak-7", title: "Week Streak", description: "7-day streak", icon: <Flame className="h-5 w-5" />, check: (s) => s.bestStreak >= 7 },
  { id: "streak-30", title: "Unstoppable", description: "30-day streak", icon: <Flame className="h-5 w-5" />, check: (s) => s.bestStreak >= 30 },
  { id: "level-5", title: "Rising Star", description: "Reach level 5", icon: <Zap className="h-5 w-5" />, check: (s) => s.level >= 5 },
  { id: "level-10", title: "Habit Builder", description: "Reach level 10", icon: <Zap className="h-5 w-5" />, check: (s) => s.level >= 10 },
  { id: "level-20", title: "Productivity Master", description: "Reach level 20", icon: <Crown className="h-5 w-5" />, check: (s) => s.level >= 20 },
];

const RANKS = [
  { level: 1, title: "Novice Planner", icon: <Star className="h-4 w-4" /> },
  { level: 3, title: "Getting Started", icon: <Target className="h-4 w-4" /> },
  { level: 5, title: "Consistent Achiever", icon: <Medal className="h-4 w-4" /> },
  { level: 10, title: "Habit Builder", icon: <Award className="h-4 w-4" /> },
  { level: 15, title: "Productivity Pro", icon: <Trophy className="h-4 w-4" /> },
  { level: 20, title: "Productivity Master", icon: <Crown className="h-4 w-4" /> },
  { level: 30, title: "Productivity Legend", icon: <Crown className="h-5 w-5 text-amber-500" /> },
];

export function GamificationView() {
  const tasks = useStore((s) => s.tasks);
  const reviews = useStore((s) => s.reviews);
  const game = useStore((s) => s.game);

  const completedTasks = tasks.filter((t) => t.status === "completed").length;
  const reviewCount = Object.keys(reviews).length;
  const lvl = levelForXp(game.xp);
  const currentRank = RANKS.filter((r) => r.level <= lvl.level).pop() ?? RANKS[0];
  const nextRank = RANKS.find((r) => r.level > lvl.level);

  const stats = {
    tasks: tasks.length,
    completed: completedTasks,
    reviews: reviewCount,
    streak: game.streak,
    bestStreak: game.bestStreak,
    level: lvl.level,
  };

  const unlocked = new Set(game.achievements.map((a) => a.id));
  // Also dynamically check (in case achievement wasn't recorded)
  ACHIEVEMENTS.forEach((a) => {
    if (a.check(stats)) unlocked.add(a.id);
  });

  return (
    <div className="space-y-4">
      {/* Hero rank card */}
      <Card className="p-5 sm:p-6 relative overflow-hidden bg-gradient-to-br from-emerald-500/10 via-cyan-500/5 to-purple-500/10 border-emerald-500/30">
        <div className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-20 bg-emerald-500" />
        <div className="relative grid sm:grid-cols-2 gap-6 items-center">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs uppercase tracking-wide text-muted-foreground">Current Rank</span>
            </div>
            <div className="flex items-center gap-2 mb-2">
              {currentRank.icon}
              <h2 className="text-2xl font-bold">{currentRank.title}</h2>
            </div>
            <div className="flex items-baseline gap-2 mb-3">
              <span className="text-4xl font-bold text-emerald-600 dark:text-emerald-400">Lv {lvl.level}</span>
              <span className="text-sm text-muted-foreground">{game.xp} XP total</span>
            </div>
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-muted-foreground">Progress to Level {lvl.level + 1}</span>
                <span className="font-medium">{lvl.intoLevel}/{lvl.neededForNext}</span>
              </div>
              <Progress value={lvl.pct} className="h-2" />
            </div>
            {nextRank && (
              <p className="text-xs text-muted-foreground mt-2">
                Next: <span className="font-medium">{nextRank.title}</span> at Lv {nextRank.level}
              </p>
            )}
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <div className="text-2xl font-bold text-orange-500">{game.streak}</div>
              <div className="text-[10px] text-muted-foreground uppercase">Day Streak</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-amber-500">{game.bestStreak}</div>
              <div className="text-[10px] text-muted-foreground uppercase">Best Streak</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-emerald-500">{completedTasks}</div>
              <div className="text-[10px] text-muted-foreground uppercase">Tasks Done</div>
            </div>
          </div>
        </div>
      </Card>

      {/* Rank ladder */}
      <Card className="p-4 sm:p-5">
        <h3 className="text-sm font-semibold mb-3">Rank Ladder</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {RANKS.map((r) => {
            const reached = lvl.level >= r.level;
            return (
              <div
                key={r.level}
                className={`p-3 rounded-md border text-center transition ${
                  reached
                    ? "border-emerald-500/40 bg-emerald-500/5"
                    : "border-border bg-muted/30 opacity-60"
                }`}
              >
                <div className={`flex justify-center mb-1 ${reached ? "text-emerald-500" : "text-muted-foreground"}`}>
                  {r.icon}
                </div>
                <div className="text-xs font-semibold">Lv {r.level}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">{r.title}</div>
                {reached && (
                  <Badge variant="secondary" className="mt-1 text-[9px] bg-emerald-500/15 text-emerald-600">
                    Unlocked
                  </Badge>
                )}
              </div>
            );
          })}
        </div>
      </Card>

      {/* Achievements grid */}
      <Card className="p-4 sm:p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">Achievements</h3>
          <Badge variant="secondary">
            {unlocked.size}/{ACHIEVEMENTS.length}
          </Badge>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {ACHIEVEMENTS.map((a) => {
            const isUnlocked = unlocked.has(a.id);
            return (
              <div
                key={a.id}
                className={`p-4 rounded-lg border text-center transition ${
                  isUnlocked
                    ? "border-emerald-500/40 bg-emerald-500/5"
                    : "border-border bg-muted/20 opacity-70"
                }`}
              >
                <div
                  className={`mx-auto mb-2 w-12 h-12 rounded-full flex items-center justify-center ${
                    isUnlocked ? "bg-emerald-500/15 text-emerald-500" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {a.icon}
                </div>
                <div className="text-sm font-semibold">{a.title}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">{a.description}</div>
                {isUnlocked ? (
                  <Badge variant="secondary" className="mt-2 text-[9px] bg-emerald-500/15 text-emerald-600">
                    Unlocked
                  </Badge>
                ) : (
                  <Badge variant="outline" className="mt-2 text-[9px]">Locked</Badge>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
