"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import {
  Moon,
  Sun,
  Settings as Cog,
  Download,
  Upload,
  Trash2,
  Plus,
  Tag as TagIcon,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { useStore } from "@/lib/store";
import { colorOf } from "@/lib/types";
import { toast } from "sonner";

const ACCENT_OPTIONS = [
  { name: "emerald", hex: "#10b981" },
  { name: "cyan", hex: "#06b6d4" },
  { name: "amber", hex: "#f59e0b" },
  { name: "purple", hex: "#8b5cf6" },
  { name: "rose", hex: "#f43f5e" },
  { name: "orange", hex: "#f97316" },
];

export function SettingsView() {
  const { theme, setTheme } = useTheme();
  const settings = useStore((s) => s.settings);
  const updateSettings = useStore((s) => s.updateSettings);
  const categories = useStore((s) => s.categories);
  const addCategory = useStore((s) => s.addCategory);
  const deleteCategory = useStore((s) => s.deleteCategory);
  const importData = useStore((s) => s.importData);
  const clearAll = useStore((s) => s.clearAll);

  const [newCatOpen, setNewCatOpen] = React.useState(false);
  const [newCatName, setNewCatName] = React.useState("");
  const [newCatColor, setNewCatColor] = React.useState("emerald");
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleExportJSON = () => {
    const data = useStore.getState();
    const blob = new Blob(
      [JSON.stringify({
        tasks: data.tasks,
        reviews: data.reviews,
        categories: data.categories,
        settings: data.settings,
        game: data.game,
      }, null, 2)],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `flowdeck-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Backup exported");
  };

  const handleExportCSV = () => {
    const data = useStore.getState();
    const headers = ["id", "title", "date", "startTime", "endTime", "priority", "categoryId", "status", "estimatedMin", "actualMin", "tags", "notes"];
    const rows = data.tasks.map((t) => [
      t.id,
      `"${t.title.replace(/"/g, '""')}"`,
      t.date,
      t.startTime ?? "",
      t.endTime ?? "",
      t.priority,
      t.categoryId,
      t.status,
      t.estimatedMin ?? "",
      t.actualMin ?? "",
      `"${t.tags.join("|")}"`,
      `"${(t.notes ?? "").replace(/"/g, '""')}"`,
    ].join(","));
    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `flowdeck-tasks-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV exported");
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result as string);
        importData(data);
        toast.success("Data imported");
      } catch (err) {
        toast.error("Invalid backup file");
      }
    };
    reader.readAsText(file);
  };

  const handleClear = () => {
    if (confirm("This will delete ALL tasks, reviews, and progress. This cannot be undone. Continue?")) {
      clearAll();
      toast.success("All data cleared");
    }
  };

  const handleAddCategory = () => {
    if (!newCatName.trim()) {
      toast.error("Category name is required");
      return;
    }
    addCategory({ name: newCatName.trim(), color: newCatColor });
    toast.success("Category added");
    setNewCatName("");
    setNewCatOpen(false);
  };

  return (
    <div className="space-y-4">
      <Tabs defaultValue="appearance">
        <TabsList className="grid grid-cols-2 sm:grid-cols-4 w-full sm:w-auto">
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="data">Data</TabsTrigger>
        </TabsList>

        {/* Appearance */}
        <TabsContent value="appearance" className="mt-4 space-y-4">
          <Card className="p-4 sm:p-5 space-y-4">
            <div className="flex items-center gap-2 mb-1">
              <Cog className="h-4 w-4 text-emerald-500" />
              <h3 className="text-sm font-semibold">Theme & Colors</h3>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-xs uppercase text-muted-foreground">Theme Mode</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {(["light", "dark", "system"] as const).map((t) => (
                    <Button
                      key={t}
                      variant={theme === t ? "default" : "outline"}
                      size="sm"
                      onClick={() => setTheme(t)}
                      className="capitalize"
                    >
                      {t === "light" && <Sun className="h-3.5 w-3.5 mr-1" />}
                      {t === "dark" && <Moon className="h-3.5 w-3.5 mr-1" />}
                      {t}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-xs uppercase text-muted-foreground">Accent Color</Label>
                <div className="grid grid-cols-6 gap-2 mt-2">
                  {ACCENT_OPTIONS.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => updateSettings({ accent: c.name })}
                      className={`aspect-square rounded-full border-2 transition ${
                        settings.accent === c.name ? "border-foreground scale-110" : "border-transparent"
                      }`}
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                      aria-label={`Set accent ${c.name}`}
                    />
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Selected: <span className="font-medium capitalize">{settings.accent}</span>
                </p>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Schedule */}
        <TabsContent value="schedule" className="mt-4 space-y-4">
          <Card className="p-4 sm:p-5 space-y-4">
            <div className="flex items-center gap-2 mb-1">
              <Cog className="h-4 w-4 text-emerald-500" />
              <h3 className="text-sm font-semibold">Daily Schedule</h3>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="grid gap-1.5">
                <Label htmlFor="wake">Wake-up Time</Label>
                <Input
                  id="wake"
                  type="time"
                  value={settings.wakeTime}
                  onChange={(e) => updateSettings({ wakeTime: e.target.value })}
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="sleep">Sleep Time</Label>
                <Input
                  id="sleep"
                  type="time"
                  value={settings.sleepTime}
                  onChange={(e) => updateSettings({ sleepTime: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-3 pt-3 border-t">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="mr" className="text-sm">Morning Reminder</Label>
                  <p className="text-xs text-muted-foreground">Get notified to plan your day</p>
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    id="mr-time"
                    type="time"
                    value={settings.morningReminderTime}
                    onChange={(e) => updateSettings({ morningReminderTime: e.target.value })}
                    className="w-32"
                  />
                  <Switch
                    id="mr"
                    checked={settings.morningReminder}
                    onCheckedChange={(v) => updateSettings({ morningReminder: v })}
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="er" className="text-sm">Evening Review Reminder</Label>
                  <p className="text-xs text-muted-foreground">Get notified to score your day</p>
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    id="er-time"
                    type="time"
                    value={settings.eveningReminderTime}
                    onChange={(e) => updateSettings({ eveningReminderTime: e.target.value })}
                    className="w-32"
                  />
                  <Switch
                    id="er"
                    checked={settings.eveningReminder}
                    onCheckedChange={(v) => updateSettings({ eveningReminder: v })}
                  />
                </div>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 pt-3 border-t">
              <div className="grid gap-1.5">
                <Label htmlFor="lead">Task Reminder Lead Time (min)</Label>
                <Input
                  id="lead"
                  type="number"
                  value={settings.taskReminderLeadMin}
                  onChange={(e) => updateSettings({ taskReminderLeadMin: parseInt(e.target.value, 10) || 0 })}
                />
              </div>
              <div className="flex items-center justify-between p-3 border rounded-md">
                <div>
                  <Label htmlFor="we" className="text-sm">Weekend Mode</Label>
                  <p className="text-xs text-muted-foreground">Lighter reminders Sat/Sun</p>
                </div>
                <Switch
                  id="we"
                  checked={settings.weekendMode}
                  onCheckedChange={(v) => updateSettings({ weekendMode: v })}
                />
              </div>
            </div>
          </Card>

          {/* Score weights */}
          <Card className="p-4 sm:p-5 space-y-3">
            <h3 className="text-sm font-semibold">Score Formula Weights</h3>
            <p className="text-xs text-muted-foreground">
              Total must equal 100. Currently: {settings.weightCompleted + settings.weightPriority + settings.weightHabits + settings.weightTimeAccuracy}
            </p>
            <div className="grid sm:grid-cols-4 gap-3">
              <WeightInput label="Completed" value={settings.weightCompleted} onChange={(v) => updateSettings({ weightCompleted: v })} />
              <WeightInput label="Priority" value={settings.weightPriority} onChange={(v) => updateSettings({ weightPriority: v })} />
              <WeightInput label="Habits" value={settings.weightHabits} onChange={(v) => updateSettings({ weightHabits: v })} />
              <WeightInput label="Time Acc." value={settings.weightTimeAccuracy} onChange={(v) => updateSettings({ weightTimeAccuracy: v })} />
            </div>
          </Card>
        </TabsContent>

        {/* Categories */}
        <TabsContent value="categories" className="mt-4 space-y-4">
          <Card className="p-4 sm:p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <TagIcon className="h-4 w-4 text-emerald-500" />
                <h3 className="text-sm font-semibold">Categories</h3>
              </div>
              <Button size="sm" variant="outline" onClick={() => setNewCatOpen(true)}>
                <Plus className="h-3.5 w-3.5 mr-1" />
                New
              </Button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
              {categories.map((c) => (
                <div
                  key={c.id}
                  className={`p-3 rounded-md border ${colorOf(c.color).border} ${colorOf(c.color).soft} flex items-center justify-between`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={`w-2 h-2 rounded-full ${colorOf(c.color).dot}`} />
                    <span className="text-sm truncate">{c.name}</span>
                  </div>
                  <button
                    onClick={() => {
                      deleteCategory(c.id);
                      toast.success("Category deleted");
                    }}
                    className="text-muted-foreground hover:text-red-500"
                    aria-label="Delete category"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Data */}
        <TabsContent value="data" className="mt-4 space-y-4">
          <Card className="p-4 sm:p-5">
            <h3 className="text-sm font-semibold mb-3">Backup & Export</h3>
            <div className="grid sm:grid-cols-2 gap-3">
              <Button variant="outline" onClick={handleExportJSON} className="justify-start">
                <Download className="h-4 w-4 mr-2" />
                Export Full Backup (JSON)
              </Button>
              <Button variant="outline" onClick={handleExportCSV} className="justify-start">
                <Download className="h-4 w-4 mr-2" />
                Export Tasks (CSV)
              </Button>
              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                className="justify-start"
              >
                <Upload className="h-4 w-4 mr-2" />
                Import Backup (JSON)
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="application/json"
                onChange={handleImport}
                className="hidden"
              />
              <Button
                variant="outline"
                onClick={handleClear}
                className="justify-start text-red-500 hover:text-red-600 border-red-500/30 hover:bg-red-500/5"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear All Data
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              Your data is stored locally in your browser. Export regularly to avoid loss.
              Clearing cookies or browser data will erase your progress.
            </p>
          </Card>
        </TabsContent>
      </Tabs>

      {/* New category dialog */}
      <Dialog open={newCatOpen} onOpenChange={setNewCatOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New Category</DialogTitle>
            <DialogDescription>Create a custom category for your tasks.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 py-2">
            <div className="grid gap-1.5">
              <Label htmlFor="cn">Name</Label>
              <Input
                id="cn"
                placeholder="e.g. Side Project"
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                autoFocus
              />
            </div>
            <div className="grid gap-1.5">
              <Label>Color</Label>
              <div className="grid grid-cols-6 gap-2">
                {ACCENT_OPTIONS.map((c) => (
                  <button
                    key={c.name}
                    onClick={() => setNewCatColor(c.name)}
                    className={`aspect-square rounded-full border-2 transition ${
                      newCatColor === c.name ? "border-foreground scale-110" : "border-transparent"
                    }`}
                    style={{ backgroundColor: c.hex }}
                    aria-label={`Color ${c.name}`}
                  />
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setNewCatOpen(false)}>Cancel</Button>
            <Button onClick={handleAddCategory} className="bg-emerald-600 hover:bg-emerald-700 text-white">
              Add Category
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function WeightInput({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="grid gap-1.5">
      <Label className="text-xs">{label} (%)</Label>
      <Input
        type="number"
        min={0}
        max={100}
        value={value}
        onChange={(e) => onChange(Math.max(0, Math.min(100, parseInt(e.target.value, 10) || 0)))}
      />
    </div>
  );
}
