"use client";

import * as React from "react";
import { Bell, X } from "lucide-react";
import { useStore } from "@/lib/store";
import { toast } from "sonner";

interface ReminderState {
  lastFiredTaskId: string | null;
  lastMorningKey: string | null;
  lastEveningKey: string | null;
}

const STATE_KEY = "flowdeck-reminders";

export function ReminderEngine() {
  const tasks = useStore((s) => s.tasks);
  const settings = useStore((s) => s.settings);

  const stateRef = React.useRef<ReminderState>({ lastFiredTaskId: null, lastMorningKey: null, lastEveningKey: null });

  // Load state once
  React.useEffect(() => {
    try {
      const raw = localStorage.getItem(STATE_KEY);
      if (raw) stateRef.current = JSON.parse(raw);
    } catch {
      // ignore
    }
  }, []);

  const saveState = (s: ReminderState) => {
    stateRef.current = s;
    try {
      localStorage.setItem(STATE_KEY, JSON.stringify(s));
    } catch {
      // ignore
    }
  };

  // Ask for notification permission on mount
  React.useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "default") {
        // Don't auto-prompt — wait for user gesture
      }
    }
  }, []);

  // Poll every 30s for reminders
  React.useEffect(() => {
    const check = () => {
      const now = new Date();
      const todayKey = now.toISOString().slice(0, 10);
      const nowHHMM = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;

      // Morning reminder
      if (
        settings.morningReminder &&
        settings.morningReminderTime === nowHHMM &&
        stateRef.current.lastMorningKey !== todayKey
      ) {
        fireNotification(
          "🌅 Good morning!",
          "Plan your day to set yourself up for success.",
        );
        toast.info("Morning reminder — plan your day!", { duration: 8000 });
        saveState({ ...stateRef.current, lastMorningKey: todayKey });
      }

      // Evening reminder
      if (
        settings.eveningReminder &&
        settings.eveningReminderTime === nowHHMM &&
        stateRef.current.lastEveningKey !== todayKey
      ) {
        fireNotification(
          "🌙 Time to review!",
          "Score your day and reflect on what you accomplished.",
        );
        toast.info("Evening reminder — review your day!", { duration: 8000 });
        saveState({ ...stateRef.current, lastEveningKey: todayKey });
      }

      // Task reminders
      const lead = settings.taskReminderLeadMin;
      tasks.forEach((t) => {
        if (t.status !== "pending" || !t.startTime || t.date !== todayKey) return;
        const startDt = new Date(`${t.date}T${t.startTime}:00`);
        const diffMin = (startDt.getTime() - now.getTime()) / 60000;
        // Fire if within the lead window (e.g. 10 min before) and not yet fired
        if (diffMin > 0 && diffMin <= lead && diffMin > lead - 1) {
          if (stateRef.current.lastFiredTaskId !== `${t.id}-${todayKey}`) {
            fireNotification(
              `⏰ Upcoming: ${t.title}`,
              `Starts in ${Math.round(diffMin)} min at ${t.startTime}`,
            );
            toast.info(`Upcoming: ${t.title} — starts in ${Math.round(diffMin)} min`, {
              duration: 10000,
            });
            saveState({
              ...stateRef.current,
              lastFiredTaskId: `${t.id}-${todayKey}`,
            });
          }
        }
      });
    };

    check();
    const id = setInterval(check, 30_000);
    return () => clearInterval(id);
  }, [tasks, settings]);

  return null;
}

function fireNotification(title: string, body: string) {
  try {
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "granted") {
        new Notification(title, { body });
      } else if (Notification.permission === "default") {
        // Request permission on first fire
        Notification.requestPermission().then((perm) => {
          if (perm === "granted") {
            new Notification(title, { body });
          }
        });
      }
    }
  } catch (e) {
    // ignore
  }
}

// Button component to manually request notification permission
export function EnableNotificationsButton() {
  const [perm, setPerm] = React.useState<string>("");

  React.useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      setPerm(Notification.permission);
    }
  }, []);

  if (perm === "granted") {
    return (
      <span className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400">
        <Bell className="h-3 w-3" />
        Notifications on
      </span>
    );
  }

  if (perm === "denied") {
    return (
      <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
        <X className="h-3 w-3" />
        Notifications blocked
      </span>
    );
  }

  return (
    <button
      onClick={async () => {
        if (typeof window !== "undefined" && "Notification" in window) {
          const p = await Notification.requestPermission();
          setPerm(p);
          if (p === "granted") {
            toast.success("Notifications enabled");
            new Notification("🎉 FlowDeck", { body: "You'll now get reminders for tasks and reviews." });
          }
        }
      }}
      className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 hover:underline"
    >
      <Bell className="h-3 w-3" />
      Enable notifications
    </button>
  );
}
